import discord
from discord.ext import commands
from discord import app_commands
import logging
import base64

logger = logging.getLogger(__name__)

class Base64(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    base64_commands = app_commands.Group(name="base64", description="Commands for Base64 encoding and decoding.")

    @base64_commands.command(name="encode", description="Encodes text to Base64.")
    async def encode_base64(self, interaction: discord.Interaction, text: str):
        """
        Encodes the given text to Base64.
        """
        await interaction.response.defer()
        try:
            encoded_bytes = base64.b64encode(text.encode('utf-8'))
            encoded_text = encoded_bytes.decode('utf-8')

            embed = discord.Embed(
                title="Base64 Encoder",
                description=f"**Original Text:**\n```\n{text}\n```\n\n**Encoded Text:**\n```\n{encoded_text}\n```",
                color=discord.Color.green()
            )
            embed.set_footer(text=f"Requested by {interaction.user.display_name}")
            await interaction.followup.send(embed=embed)
            logger.info(f"Text encoded to Base64 by {interaction.user} in {interaction.guild.name}")

        except Exception as e:
            logger.error(f"Error encoding text to Base64: {e}", exc_info=True)
            await interaction.followup.send("An error occurred while encoding the text. Please try again later.", ephemeral=True)

    @base64_commands.command(name="decode", description="Decodes Base64 text.")
    async def decode_base64(self, interaction: discord.Interaction, text: str):
        """
        Decodes the given Base64 text.
        """
        await interaction.response.defer()
        try:
            decoded_bytes = base64.b64decode(text.encode('utf-8'))
            decoded_text = decoded_bytes.decode('utf-8')

            embed = discord.Embed(
                title="Base64 Decoder",
                description=f"**Encoded Text:**\n```\n{text}\n```\n\n**Decoded Text:**\n```\n{decoded_text}\n```",
                color=discord.Color.red()
            )
            embed.set_footer(text=f"Requested by {interaction.user.display_name}")
            await interaction.followup.send(embed=embed)
            logger.info(f"Text decoded from Base64 by {interaction.user} in {interaction.guild.name}")

        except Exception as e:
            logger.error(f"Error decoding Base64 text: {e}", exc_info=True)
            await interaction.followup.send("An error occurred while decoding the text. Please ensure it is valid Base64.", ephemeral=True)

    @base64_commands.error
    async def base64_commands_error(self, interaction: discord.Interaction, error):
        if isinstance(error, app_commands.MissingPermissions):
            logger.warning(f"User {interaction.user.id} attempted to use a Base64 command without permissions.")
            await interaction.response.send_message("You don't have permission to use this command.", ephemeral=True)
        else:
            logger.error(f"An unexpected error occurred in base64_commands_error handler for user {interaction.user.id}: {error}", exc_info=True)
            await interaction.response.send_message(f"An unexpected error occurred: {error}", ephemeral=True)

async def setup(bot):
    await bot.add_cog(Base64(bot))