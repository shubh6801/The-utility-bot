import discord
from discord.ext import commands
from discord import app_commands
import logging
import json
import os

logger = logging.getLogger(__name__)

class Level(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.xp_file = "c:\Users\srbgm\Downloads\the ticket bot\config\xp.json"
        self.user_xp = self._load_xp_data()

    def _load_xp_data(self):
        if os.path.exists(self.xp_file):
            with open(self.xp_file, 'r') as f:
                try:
                    return {int(k): v for k, v in json.load(f).items()}
                except json.JSONDecodeError:
                    logger.error(f"Error decoding JSON from {self.xp_file}. Returning empty dict.")
                    return {}
        return {}

    def _save_xp_data(self):
        with open(self.xp_file, 'w') as f:
            json.dump(self.user_xp, f, indent=4)

    level_group = app_commands.Group(name="level", description="Commands for the XP and leveling system.")

    @level_group.command(name="show", description="Show your current level and XP.")
    async def show_level(self, interaction: discord.Interaction, user: discord.Member = None):
        logger.info(f"Received /level show command from {interaction.user.name} (ID: {interaction.user.id}) in {interaction.guild.name} (ID: {interaction.guild.id})")

        target_user = user or interaction.user
        xp = self.user_xp.get(target_user.id, 0)
        level = int(xp ** 0.5) # Simple leveling formula: level = sqrt(xp)
        xp_for_next_level = (level + 1) ** 2

        embed = discord.Embed(
            title=f"{target_user.display_name}'s Level",
            description=f"**Level:** {level}\n**XP:** {xp}/{xp_for_next_level}",
            color=discord.Color.gold()
        )
        embed.set_thumbnail(url=target_user.display_avatar.url)
        embed.set_footer(text="Keep chatting to earn more XP!")

        await interaction.response.send_message(embed=embed)
        logger.info(f"Displayed level for {target_user.name} (ID: {target_user.id})")

    # This is a placeholder for an XP gain listener. In a real bot, this would be more sophisticated.
    @commands.Cog.listener()
    async def on_message(self, message):
        if message.author.bot or not message.guild:
            return

        # Simple XP gain: 1 XP per message
        user_id = message.author.id
        self.user_xp[user_id] = self.user_xp.get(user_id, 0) + 1
        self._save_xp_data()

        # Check for level up (optional, can be noisy)
        xp = self.user_xp[user_id]
        current_level = int(xp ** 0.5)
        previous_level = int((xp - 1) ** 0.5)

        if current_level > previous_level:
            logger.info(f"{message.author.name} (ID: {user_id}) leveled up to Level {current_level}!")
            # You might want to send a level-up message in a designated channel or DMs
            # await message.channel.send(f"Congratulations {message.author.mention}! You've reached Level {current_level}!")

    @level_group.error
    async def level_group_error(self, interaction: discord.Interaction, error):
        if isinstance(error, app_commands.MissingPermissions):
            logger.warning(f"User {interaction.user.id} attempted to use a level command without permissions.")
            await interaction.response.send_message("You don't have permission to use this command.", ephemeral=True)
        else:
            logger.error(f"An unexpected error occurred in level_group_error handler for user {interaction.user.id}: {error}", exc_info=True)
            await interaction.response.send_message(f"An unexpected error occurred: {error}", ephemeral=True)

async def setup(bot):
    await bot.add_cog(Level(bot))