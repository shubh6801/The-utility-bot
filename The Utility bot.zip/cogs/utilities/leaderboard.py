import discord
from discord.ext import commands
from discord import app_commands
import logging
import json
import os

logger = logging.getLogger(__name__)

class Leaderboard(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.xp_file = "c:\Users\srbgm\Downloads\the ticket bot\config\xp.json"
        self.user_xp = self._load_xp_data()

    def _load_xp_data(self):
        if os.path.exists(self.xp_file):
            with open(self.xp_file, 'r') as f:
                try:
                    return {int(k): v for k, v in json.load(f).items()}
                except json.JSONDecodeError:
                    logger.error(f"Error decoding JSON from {self.xp_file}. Returning empty dict.")
                    return {}
        return {}

    def _save_xp_data(self):
        with open(self.xp_file, 'w') as f:
            json.dump(self.user_xp, f, indent=4)

    leaderboard_group = app_commands.Group(name="leaderboard", description="Commands for displaying server rankings.")

    @leaderboard_group.command(name="xp", description="Show the server's XP leaderboard.")
    async def xp_leaderboard(self, interaction: discord.Interaction):
        logger.info(f"Received /leaderboard xp command from {interaction.user.name} (ID: {interaction.user.id}) in {interaction.guild.name} (ID: {interaction.guild.id})")

        if not interaction.guild:
            await interaction.response.send_message("This command can only be used in a server.", ephemeral=True)
            return

        await interaction.response.defer()

        # For demonstration, we'll use a dummy XP data. In a real bot, this would come from a persistent storage.
        # self.user_xp should be populated by the Level cog's on_message listener or similar mechanism.
        # For now, let's assume some dummy data or access the Level cog's data if available.
        level_cog = self.bot.get_cog("Level")
        if level_cog:
            xp_data = level_cog.user_xp
        else:
            xp_data = self.user_xp

        sorted_xp = sorted(xp_data.items(), key=lambda item: item[1], reverse=True)

        embed = discord.Embed(
            title=f"XP Leaderboard for {interaction.guild.name}",
            color=discord.Color.gold()
        )

        description = ""
        for i, (user_id, xp) in enumerate(sorted_xp[:10]): # Show top 10
            member = interaction.guild.get_member(user_id)
            if member:
                level = int(xp ** 0.5)
                description += f"{i+1}. {member.mention} - Level {level} ({xp} XP)\n"
            else:
                description += f"{i+1}. <@{user_id}> - Level {int(xp ** 0.5)} ({xp} XP) (User not found)\n"

        if not description:
            description = "No XP data available yet. Start chatting to earn XP!"

        embed.description = description
        embed.set_footer(text="Rankings based on total XP.")

        await interaction.followup.send(embed=embed)
        logger.info(f"Displayed XP leaderboard for {interaction.guild.name} (ID: {interaction.guild.id})")

    @leaderboard_group.error
    async def leaderboard_group_error(self, interaction: discord.Interaction, error):
        if isinstance(error, app_commands.MissingPermissions):
            logger.warning(f"User {interaction.user.id} attempted to use a leaderboard command without permissions.")
            await interaction.response.send_message("You don't have permission to use this command.", ephemeral=True)
        else:
            logger.error(f"An unexpected error occurred in leaderboard_group_error handler for user {interaction.user.id}: {error}", exc_info=True)
            await interaction.response.send_message(f"An unexpected error occurred: {error}", ephemeral=True)

async def setup(bot):
    await bot.add_cog(Leaderboard(bot))