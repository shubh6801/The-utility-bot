import discord
from discord.ext import commands
from discord import app_commands
import logging
import os

from googletrans import Translator, LANGUAGES

logger = logging.getLogger(__name__)

class Translate(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.translator = Translator()

    @app_commands.command(name="translate", description="Translates text to a specified language.")
    @app_commands.describe(
        text="The text to translate.",
        target_language="The language to translate to (e.g., 'en' for English, 'es' for Spanish)."
    )
    async def translate(self, 
                        interaction: discord.Interaction,
                        text: str,
                        target_language: str = "en"
                       ):
        logger.info(f"Received /translate command from {interaction.user.name} ({interaction.user.id}) in {interaction.guild.name} ({interaction.guild.id})")
        try:
            # Validate target_language
            if target_language.lower() not in LANGUAGES and target_language not in LANGUAGES.values():
                await interaction.response.send_message(f"Invalid target language code or name. Please use a valid language code (e.g., 'en') or name (e.g., 'English').", ephemeral=True)
                logger.warning(f"[/translate] Invalid target language '{target_language}' provided by {interaction.user.name}")
                return

            # Convert language name to code if a name was provided
            if target_language.lower() in LANGUAGES.values():
                for code, name in LANGUAGES.items():
                    if name == target_language.lower():
                        target_language = code
                        break
            
            # Perform translation
            translated_text = self.translator.translate(text, dest=target_language).text

            embed = discord.Embed(
                title="Text Translation",
                color=discord.Color.green()
            )
            embed.add_field(name="Original Text", value=text, inline=False)
            embed.add_field(name=f"Translated Text ({target_language.upper()})", value=translated_text, inline=False)
            embed.set_footer(text=f"Requested by {interaction.user.display_name}")

            await interaction.response.send_message(embed=embed)
            logger.info(f"[/translate] Successfully translated text for {interaction.user.name}")

        except Exception as e:
            logger.error(f"Error in /translate command for {interaction.user.name} ({interaction.user.id}): {e}", exc_info=True)
            await interaction.response.send_message("An unexpected error occurred during translation. Please try again later.", ephemeral=True)

    @translate.error
    async def translate_error(self, interaction: discord.Interaction, error):
        if isinstance(error, app_commands.MissingPermissions):
            logger.warning(f"User {interaction.user.id} attempted to use the translate command without permissions.")
            await interaction.response.send_message("You don't have permission to use this command.", ephemeral=True)
        else:
            logger.error(f"An unexpected error occurred in translate_error handler for user {interaction.user.id}: {error}", exc_info=True)
            await interaction.response.send_message(f"An unexpected error occurred: {error}", ephemeral=True)

async def setup(bot):
    await bot.add_cog(Translate(bot))