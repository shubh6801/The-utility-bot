import logging
import discord
from discord.ext import commands
from discord import app_commands
import qrcode
import io

logger = logging.getLogger(__name__)

class QR(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    qr_group = app_commands.Group(name="qr", description="Commands for QR code generation")

    @qr_group.command(name="generate", description="Generate a QR code from text")
    async def generate_qr(self, interaction: discord.Interaction, text: str):
        logger.info(f"Received /qr generate command from {interaction.user.name} for text: {text}")
        await interaction.response.defer()

        try:
            qr_img = qrcode.make(text)
            buffer = io.BytesIO()
            qr_img.save(buffer, format="PNG")
            buffer.seek(0)

            file = discord.File(buffer, filename="qrcode.png")
            embed = discord.Embed(
                title="QR Code Generated",
                description=f"Here is your QR code for: `{text}`",
                color=discord.Color.blue()
            )
            embed.set_image(url="attachment://qrcode.png")
            await interaction.followup.send(embed=embed, file=file)
            logger.info(f"Successfully generated QR code for text: {text}")
        except Exception as e:
            embed = discord.Embed(
                title="Error",
                description=f"An unexpected error occurred while generating the QR code: {e}",
                color=discord.Color.red()
            )
            await interaction.followup.send(embed=embed)
            logger.error(f"Unexpected error while generating QR code for text {text}: {e}", exc_info=True)

    @qr_group.error
    async def qr_group_error(self, interaction: discord.Interaction, error):
        if isinstance(error, app_commands.MissingPermissions):
            logger.warning(f"User {interaction.user.id} attempted to use a QR command without permissions.")
            await interaction.response.send_message("You don't have permission to use this command.", ephemeral=True)
        else:
            logger.error(f"An unexpected error occurred in qr_group_error handler for user {interaction.user.id}: {error}", exc_info=True)
            await interaction.response.send_message(f"An unexpected error occurred: {error}", ephemeral=True)

async def setup(bot):
    await bot.add_cog(QR(bot))