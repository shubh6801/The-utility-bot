import discord
from discord.ext import commands
from discord import app_commands
import logging
import json
import os

logger = logging.getLogger(__name__)

class Ticket(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.config_file = "c:\Users\srbgm\Downloads\the ticket bot\config\ticket_config.json"
        self.ticket_configs = self._load_config()

    def _load_config(self):
        if os.path.exists(self.config_file):
            with open(self.config_file, 'r') as f:
                try:
                    return json.load(f)
                except json.JSONDecodeError:
                    logger.error(f"Error decoding JSON from {self.config_file}. Returning empty dict.")
                    return {}
        return {}

    def _save_config(self):
        with open(self.config_file, 'w') as f:
            json.dump(self.ticket_configs, f, indent=4)

    ticket = app_commands.Group(name="ticket", description="Commands for managing support tickets.")

    @ticket.command(name="create", description="Create a new support ticket.")
    @app_commands.describe(
        subject="The subject of your support ticket."
    )
    async def create_ticket(self, 
                            interaction: discord.Interaction,
                            subject: str = "No Subject Provided"
                           ):
        logger.info(f"Received /ticket create command from {interaction.user.name} (ID: {interaction.user.id}) in {interaction.guild.name} (ID: {interaction.guild.id})")

        if not interaction.guild:
            await interaction.response.send_message("This command can only be used in a server.", ephemeral=True)
            return

        guild_id = str(interaction.guild.id)
        if guild_id not in self.ticket_configs or "category_id" not in self.ticket_configs[guild_id]:
            await interaction.response.send_message("Ticket category is not configured for this server. Please contact an administrator.", ephemeral=True)
            return

        ticket_category_id = self.ticket_configs[guild_id]["category_id"]
        category = discord.utils.get(interaction.guild.categories, id=ticket_category_id)
        if not category:
            await interaction.response.send_message("Ticket category not found. It might have been deleted. Please contact an administrator.", ephemeral=True)
            return

        overwrites = {
            interaction.guild.default_role: discord.PermissionOverwrite(read_messages=False),
            interaction.user: discord.PermissionOverwrite(read_messages=True, send_messages=True, embed_links=True, attach_files=True),
            interaction.guild.me: discord.PermissionOverwrite(read_messages=True, send_messages=True, embed_links=True, attach_files=True)
        }

        try:
            ticket_channel = await category.create_text_channel(
                name=f"ticket-{interaction.user.name.lower().replace(' ', '-')}",
                overwrites=overwrites,
                topic=f"Support ticket for {interaction.user.name}. Subject: {subject}"
            )
            embed = discord.Embed(
                title="New Support Ticket",
                description=f"Welcome to your support ticket, {interaction.user.mention}!\n" \
                            f"A staff member will be with you shortly.\n\n" \
                            f"**Subject:** {subject}",
                color=discord.Color.blue()
            )
            embed.set_footer(text=f"Ticket created by {interaction.user.name}", icon_url=interaction.user.display_avatar.url)
            await ticket_channel.send(embed=embed)
            await interaction.response.send_message(f"Your ticket has been created: {ticket_channel.mention}", ephemeral=True)
            logger.info(f"Ticket channel {ticket_channel.name} created for {interaction.user.name} (ID: {interaction.user.id})")
        except discord.Forbidden:
            logger.error(f"Bot lacks permissions to create ticket channel in {interaction.guild.name} (ID: {interaction.guild.id})", exc_info=True)
            await interaction.response.send_message("I don't have permission to create channels. Please check my role permissions.", ephemeral=True)
        except Exception as e:
            logger.error(f"Error creating ticket for {interaction.user.name} (ID: {interaction.user.id}): {e}", exc_info=True)
            await interaction.response.send_message("An unexpected error occurred while creating your ticket. Please try again later.", ephemeral=True)

    @ticket.command(name="set_category", description="Sets the category for new support tickets.")
    @app_commands.describe(category="The category to set for tickets.")
    @app_commands.default_permissions(manage_channels=True)
    async def set_ticket_category(self, interaction: discord.Interaction, category: discord.CategoryChannel):
        logger.info(f"Received /ticket set_category command from {interaction.user.name} ({interaction.user.id}) in {interaction.guild.name} ({interaction.guild.id}) for category {category.name} (ID: {category.id})")
        if not interaction.guild:
            await interaction.response.send_message("This command can only be used in a server.", ephemeral=True)
            return

        guild_id = str(interaction.guild.id)
        if guild_id not in self.ticket_configs:
            self.ticket_configs[guild_id] = {}

        self.ticket_configs[guild_id]["category_id"] = category.id
        self._save_config()

        embed = discord.Embed(
            title="Ticket Category Set",
            description=f"New tickets will now be created in the category: {category.name}.",
            color=discord.Color.green()
        )
        await interaction.response.send_message(embed=embed, ephemeral=True)
        logger.info(f"Ticket category for guild {guild_id} set to {category.name} (ID: {category.id}).")

    @ticket.error
    async def ticket_error(self, interaction: discord.Interaction, error):
        if isinstance(error, app_commands.MissingPermissions):
            logger.warning(f"User {interaction.user.id} attempted to use a ticket command without permissions.")
            await interaction.response.send_message("You don't have permission to use this command.", ephemeral=True)
        else:
            logger.error(f"An unexpected error occurred in ticket_error handler for user {interaction.user.id}: {error}", exc_info=True)
            await interaction.response.send_message(f"An unexpected error occurred: {error}", ephemeral=True)

async def setup(bot):
    await bot.add_cog(Ticket(bot))