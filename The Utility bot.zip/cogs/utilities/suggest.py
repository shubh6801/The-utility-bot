import logging
import discord
from discord.ext import commands
from discord import app_commands
import json
import os
from datetime import datetime

logger = logging.getLogger(__name__)

class Suggest(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.suggestions_file = "c:\Users\srbgm\Downloads\the ticket bot\config\suggestions.json"
        self.suggestions_config = self._load_suggestions_config()

    def _load_suggestions_config(self):
        if os.path.exists(self.suggestions_file):
            with open(self.suggestions_file, 'r') as f:
                try:
                    return json.load(f)
                except json.JSONDecodeError:
                    logger.error(f"Error decoding JSON from {self.suggestions_file}. Returning empty list.")
                    return []
        return []

    def _save_suggestions_config(self):
        with open(self.suggestions_file, 'w') as f:
            json.dump(self.suggestions_config, f, indent=4)

    @app_commands.command(name="suggest", description="Submits a suggestion.")
    @app_commands.describe(
        idea="Your suggestion."
    )
    async def suggest(self, 
                      interaction: discord.Interaction,
                      idea: str
                     ):
        logger.info(f"Received /suggest command from {interaction.user.name} ({interaction.user.id}) in {interaction.guild.name} ({interaction.guild.id})")
        try:
            if not interaction.guild:
                await interaction.response.send_message("This command can only be used in a server.", ephemeral=True)
                return

            guild_id = str(interaction.guild.id)
            if guild_id not in self.suggestions_config:
                self.suggestions_config[guild_id] = {"channel_id": None, "suggestions": []}

            suggestion_data = {
                "user_id": interaction.user.id,
                "username": interaction.user.name,
                "idea": idea,
                "timestamp": datetime.now().isoformat()
            }
            self.suggestions_config[guild_id]["suggestions"].append(suggestion_data)
            self._save_suggestions_config()

            embed = discord.Embed(
                title="Suggestion Received!",
                description=f"Thank you for your suggestion, {interaction.user.mention}!",
                color=discord.Color.gold()
            )
            embed.add_field(name="Your Idea", value=idea, inline=False)
            embed.set_footer(text=f"Suggestion by {interaction.user.display_name}")

            await interaction.response.send_message(embed=embed, ephemeral=True)
            logger.info(f"[/suggest] Successfully received suggestion from {interaction.user.name}: {idea}")

            suggestion_channel_id = self.suggestions_config[guild_id]["channel_id"]
            if suggestion_channel_id:
                suggestion_channel = self.bot.get_channel(suggestion_channel_id)
                if suggestion_channel:
                    suggestion_embed = discord.Embed(
                        title="New Suggestion",
                        description=idea,
                        color=discord.Color.blue()
                    )
                    suggestion_embed.set_author(name=interaction.user.display_name, icon_url=interaction.user.display_avatar.url)
                    suggestion_embed.set_footer(text=f"User ID: {interaction.user.id}")
                    await suggestion_channel.send(embed=suggestion_embed)
                    logger.info(f"Sent suggestion to channel {suggestion_channel.name} (ID: {suggestion_channel_id})")
                else:
                    logger.warning(f"Configured suggestion channel (ID: {suggestion_channel_id}) not found for guild {guild_id}.")
            else:
                logger.info(f"No suggestion channel configured for guild {guild_id}.")

        except Exception as e:
            logger.error(f"Error in /suggest command for {interaction.user.name} ({interaction.user.id}): {e}", exc_info=True)
            await interaction.response.send_message("An unexpected error occurred while submitting your suggestion. Please try again later.", ephemeral=True)

    @app_commands.command(name="set_suggestion_channel", description="Sets the channel where suggestions will be sent.")
    @app_commands.describe(channel="The channel to set as the suggestion channel.")
    @app_commands.default_permissions(manage_guild=True)
    async def set_suggestion_channel(self, interaction: discord.Interaction, channel: discord.TextChannel):
        logger.info(f"Received /set_suggestion_channel command from {interaction.user.name} ({interaction.user.id}) in {interaction.guild.name} ({interaction.guild.id}) for channel {channel.name} (ID: {channel.id})")
        if not interaction.guild:
            await interaction.response.send_message("This command can only be used in a server.", ephemeral=True)
            return

        guild_id = str(interaction.guild.id)
        if guild_id not in self.suggestions_config:
            self.suggestions_config[guild_id] = {"channel_id": None, "suggestions": []}

        self.suggestions_config[guild_id]["channel_id"] = channel.id
        self._save_suggestions_config()

        embed = discord.Embed(
            title="Suggestion Channel Set",
            description=f"Suggestions will now be sent to {channel.mention}.",
            color=discord.Color.green()
        )
        await interaction.response.send_message(embed=embed, ephemeral=True)
        logger.info(f"Suggestion channel for guild {guild_id} set to {channel.name} (ID: {channel.id}).")

    @suggest.error
    async def suggest_error(self, interaction: discord.Interaction, error):
        if isinstance(error, app_commands.MissingPermissions):
            logger.warning(f"User {interaction.user.id} attempted to use the suggest command without permissions.")
            await interaction.response.send_message("You don't have permission to use this command.", ephemeral=True)
        else:
            logger.error(f"An unexpected error occurred in suggest_error handler for user {interaction.user.id}: {error}", exc_info=True)
            await interaction.response.send_message(f"An unexpected error occurred: {error}", ephemeral=True)

async def setup(bot):
    await bot.add_cog(Suggest(bot))