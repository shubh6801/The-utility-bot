import discord
from discord.ext import commands
from discord import app_commands, ui
import logging

logger = logging.getLogger(__name__)

class AddFieldModal(ui.Modal, title="Add Field to Embed"):
    field_name = ui.TextInput(label="Field Name", placeholder="Enter the name of the field", max_length=256)
    field_value = ui.TextInput(label="Field Value", placeholder="Enter the value of the field", style=discord.TextStyle.paragraph)
    field_inline = ui.TextInput(label="Inline? (True/False)", placeholder="True or False", max_length=5)

    def __init__(self, embed: discord.Embed, view: ui.View):
        super().__init__()
        self.embed = embed
        self.view = view

    async def on_submit(self, interaction: discord.Interaction):
        inline = self.field_inline.value.lower() == 'true'
        self.embed.add_field(name=self.field_name.value, value=self.field_value.value, inline=inline)
        await interaction.response.edit_message(embed=self.embed, view=self.view)
        logger.info(f"Field added to embed by {interaction.user.name} in {interaction.guild.name}")


class SetAuthorModal(ui.Modal, title="Set Embed Author"):
    author_name = ui.TextInput(label="Author Name", placeholder="Enter the author's name", required=False, max_length=256)
    author_icon_url = ui.TextInput(label="Author Icon URL", placeholder="Enter the URL for the author's icon", required=False)

    def __init__(self, embed: discord.Embed, view: ui.View):
        super().__init__()
        self.embed = embed
        self.view = view

    async def on_submit(self, interaction: discord.Interaction):
        self.embed.set_author(name=self.author_name.value or None, icon_url=self.author_icon_url.value or None)
        await interaction.response.edit_message(embed=self.embed, view=self.view)
        logger.info(f"Author set for embed by {interaction.user.name} in {interaction.guild.name}")


class SetFooterModal(ui.Modal, title="Set Embed Footer"):
    footer_text = ui.TextInput(label="Footer Text", placeholder="Enter the footer text", required=False, max_length=2048)
    footer_icon_url = ui.TextInput(label="Footer Icon URL", placeholder="Enter the URL for the footer's icon", required=False)

    def __init__(self, embed: discord.Embed, view: ui.View):
        super().__init__()
        self.embed = embed
        self.view = view

    async def on_submit(self, interaction: discord.Interaction):
        self.embed.set_footer(text=self.footer_text.value or None, icon_url=self.footer_icon_url.value or None)
        await interaction.response.edit_message(embed=self.embed, view=self.view)
        logger.info(f"Footer set for embed by {interaction.user.name} in {interaction.guild.name}")


class SetImageModal(ui.Modal, title="Set Embed Image"):
    image_url = ui.TextInput(label="Image URL", placeholder="Enter the URL for the embed image", required=False)

    def __init__(self, embed: discord.Embed, view: ui.View):
        super().__init__()
        self.embed = embed
        self.view = view

    async def on_submit(self, interaction: discord.Interaction):
        self.embed.set_image(url=self.image_url.value or None)
        await interaction.response.edit_message(embed=self.embed, view=self.view)
        logger.info(f"Image set for embed by {interaction.user.name} in {interaction.guild.name}")


class SetThumbnailModal(ui.Modal, title="Set Embed Thumbnail"):
    thumbnail_url = ui.TextInput(label="Thumbnail URL", placeholder="Enter the URL for the embed thumbnail", required=False)

    def __init__(self, embed: discord.Embed, view: ui.View):
        super().__init__()
        self.embed = embed
        self.view = view

    async def on_submit(self, interaction: discord.Interaction):
        self.embed.set_thumbnail(url=self.thumbnail_url.value or None)
        await interaction.response.edit_message(embed=self.embed, view=self.view)
        logger.info(f"Thumbnail set for embed by {interaction.user.name} in {interaction.guild.name}")


class EmbedBuilderView(ui.View):
    def __init__(self, embed: discord.Embed):
        super().__init__(timeout=300) # 5 minutes timeout
        self.embed = embed

    @ui.button(label="Add Field", style=discord.ButtonStyle.primary)
    async def add_field_button(self, button: ui.Button, interaction: discord.Interaction):
        await interaction.response.send_modal(AddFieldModal(embed=self.embed, view=self))

    @ui.button(label="Set Author", style=discord.ButtonStyle.primary)
    async def set_author_button(self, button: ui.Button, interaction: discord.Interaction):
        await interaction.response.send_modal(SetAuthorModal(embed=self.embed, view=self))

    @ui.button(label="Set Footer", style=discord.ButtonStyle.primary)
    async def set_footer_button(self, button: ui.Button, interaction: discord.Interaction):
        await interaction.response.send_modal(SetFooterModal(embed=self.embed, view=self))

    @ui.button(label="Set Image", style=discord.ButtonStyle.primary)
    async def set_image_button(self, button: ui.Button, interaction: discord.Interaction):
        await interaction.response.send_modal(SetImageModal(embed=self.embed, view=self))

    @ui.button(label="Set Thumbnail", style=discord.ButtonStyle.primary)
    async def set_thumbnail_button(self, button: ui.Button, interaction: discord.Interaction):
        await interaction.response.send_modal(SetThumbnailModal(embed=self.embed, view=self))

    @ui.button(label="Send Embed", style=discord.ButtonStyle.success)
    async def send_embed_button(self, button: ui.Button, interaction: discord.Interaction):
        await interaction.response.send_message("Sending embed...", ephemeral=True)
        await interaction.channel.send(embed=self.embed)
        logger.info(f"Embed sent by {interaction.user.name} in {interaction.guild.name}")
        self.stop()


class EmbedBuilderModal(ui.Modal, title="Create Your Embed"):
    title_input = ui.TextInput(label="Embed Title", placeholder="Enter the title of your embed", required=False, max_length=256)
    description_input = ui.TextInput(label="Embed Description", placeholder="Enter the description of your embed", style=discord.TextStyle.paragraph, required=False)
    color_input = ui.TextInput(label="Embed Color (Hex Code)", placeholder="e.g., #RRGGBB or RRGGBB", required=False, max_length=7)

    async def on_submit(self, interaction: discord.Interaction):
        embed = discord.Embed(
            title=self.title_input.value or None,
            description=self.description_input.value or None,
            color=discord.Color.blue() # Default color
        )

        if self.color_input.value:
            try:
                hex_code = self.color_input.value.lstrip('#')
                if len(hex_code) == 6:
                    embed.color = int(hex_code, 16)
                else:
                    await interaction.response.send_message("Invalid hex color code. Using default blue.", ephemeral=True)
                    return
            except ValueError:
                await interaction.response.send_message("Invalid hex color code. Using default blue.", ephemeral=True)
                return

        view = EmbedBuilderView(embed)
        await interaction.response.send_message("Embed created! Use the buttons below to customize it.", embed=embed, view=view, ephemeral=True)
        logger.info(f"Initial embed created by {interaction.user.name} in {interaction.guild.name}")


class EmbedBuilder(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="embedbuilder", description="Interactively build a custom embed message.")
    async def embedbuilder(self, interaction: discord.Interaction):
        try:
            await interaction.response.send_modal(EmbedBuilderModal())
            logger.info(f"Embed builder command used by {interaction.user.name} in {interaction.guild.name}")
        except Exception as e:
            logger.error(f"Error in embed builder command: {e}")
            await interaction.response.send_message("An error occurred while trying to build the embed.", ephemeral=True)

async def setup(bot):
    await bot.add_cog(EmbedBuilder(bot))