import discord
from discord.ext import commands, tasks
from discord import app_commands
import logging
import asyncio
from datetime import datetime, timedelta
import json
import os

logger = logging.getLogger(__name__)

class Remind(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.reminders_file = "c:\Users\srbgm\Downloads\the ticket bot\config\reminders.json"
        self.reminders = self._load_reminders()

    def _load_reminders(self):
        if os.path.exists(self.reminders_file):
            with open(self.reminders_file, 'r') as f:
                try:
                    reminders_data = json.load(f)
                    for reminder in reminders_data:
                        reminder['remind_at'] = datetime.fromisoformat(reminder['remind_at'])
                    return reminders_data
                except json.JSONDecodeError:
                    logger.error(f"Error decoding JSON from {self.reminders_file}. Returning empty list.")
                    return []
        return []

    def _save_reminders(self):
        with open(self.reminders_file, 'w') as f:
            serializable_reminders = []
            for reminder in self.reminders:
                serializable_reminder = reminder.copy()
                serializable_reminder['remind_at'] = reminder['remind_at'].isoformat()
                serializable_reminders.append(serializable_reminder)
            json.dump(serializable_reminders, f, indent=4)

    @app_commands.command(name="remind", description="Sets a personal reminder.")
    @app_commands.describe(
        time="When to remind you (e.g., '1h', '30m', '1d').",
        message="The message for your reminder."
    )
    async def remind(self, 
                     interaction: discord.Interaction,
                     time: str,
                     message: str
                    ):
        logger.info(f"Received /remind command from {interaction.user.name} ({interaction.user.id}) in {interaction.guild.name} ({interaction.guild.id})")
        try:
            remind_time = self.parse_time(time)
            if remind_time is None:
                await interaction.response.send_message("Invalid time format. Please use formats like '1h', '30m', '1d'.", ephemeral=True)
                logger.warning(f"[/remind] Invalid time format provided by {interaction.user.name}: {time}")
                return

            reminder_timestamp = datetime.now() + remind_time
            self.reminders.append({
                'user_id': interaction.user.id,
                'channel_id': interaction.channel.id,
                'message': message,
                'remind_at': reminder_timestamp
            })
            self._save_reminders()

            await interaction.response.send_message(f"I will remind you about '**{message}**' on <t:{int(reminder_timestamp.timestamp())}:F>.", ephemeral=False)
            logger.info(f"[/remind] Reminder set for {interaction.user.name} at {reminder_timestamp}")

        except Exception as e:
            logger.error(f"Error in /remind command for {interaction.user.name} ({interaction.user.id}): {e}", exc_info=True)
            await interaction.response.send_message("An unexpected error occurred while setting the reminder. Please try again later.", ephemeral=True)

    def parse_time(self, time_str: str):
        amount = int(time_str[:-1])
        unit = time_str[-1].lower()

        if unit == 's':
            return timedelta(seconds=amount)
        elif unit == 'm':
            return timedelta(minutes=amount)
        elif unit == 'h':
            return timedelta(hours=amount)
        elif unit == 'd':
            return timedelta(days=amount)
        else:
            return None

    @tasks.loop(seconds=60) # Check for reminders every minute
    async def check_reminders(self):
        now = datetime.now()
        reminders_to_remove = []

        for reminder in self.reminders:
            if now >= reminder['remind_at']:
                user = self.bot.get_user(reminder['user_id'])
                channel = self.bot.get_channel(reminder['channel_id'])

                if user and channel:
                    try:
                        await channel.send(f"Hey {user.mention}, you asked me to remind you: **{reminder['message']}**")
                        logger.info(f"Reminder sent to {user.name} in channel {channel.name}")
                    except Exception as e:
                        logger.error(f"Failed to send reminder to {user.name} in channel {channel.name}: {e}", exc_info=True)
                else:
                    logger.warning(f"Could not find user or channel for reminder: {reminder}")
                reminders_to_remove.append(reminder)
        
        for reminder in reminders_to_remove:
            self.reminders.remove(reminder)
        if reminders_to_remove:
            self._save_reminders()

    @commands.Cog.listener()
    async def on_ready(self):
        if not self.check_reminders.is_running():
            self.check_reminders.start()

    @remind.error
    async def remind_error(self, interaction: discord.Interaction, error):
        if isinstance(error, app_commands.MissingPermissions):
            logger.warning(f"User {interaction.user.id} attempted to use the remind command without permissions.")
            await interaction.response.send_message("You don't have permission to use this command.", ephemeral=True)
        else:
            logger.error(f"An unexpected error occurred in remind_error handler for user {interaction.user.id}: {error}", exc_info=True)
            await interaction.response.send_message(f"An unexpected error occurred: {error}", ephemeral=True)

async def setup(bot):
    await bot.add_cog(Remind(bot))