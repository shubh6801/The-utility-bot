import logging
import discord
from discord.ext import commands
from discord import app_commands

logger = logging.getLogger(__name__)

class Color(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    color_group = app_commands.Group(name="color", description="Commands for color information")

    @color_group.command(name="info", description="Display information about a given hex color")
    async def color_info(self, interaction: discord.Interaction, hex_code: str):
        logger.info(f"Received /color info command from {interaction.user.name} for hex: {hex_code}")
        await interaction.response.defer()

        hex_code = hex_code.lstrip('#')

        if not all(c in '0123456789abcdefABCDEF' for c in hex_code) or len(hex_code) not in (3, 6):
            embed = discord.Embed(
                title="Invalid Hex Code",
                description="Please provide a valid 3 or 6 digit hexadecimal color code.",
                color=discord.Color.red()
            )
            await interaction.followup.send(embed=embed)
            logger.warning(f"Invalid hex code provided by {interaction.user.name}: {hex_code}")
            return

        try:
            if len(hex_code) == 3:
                hex_code = ''.join([c*2 for c in hex_code])
            
            decimal_color = int(hex_code, 16)
            r = int(hex_code[0:2], 16)
            g = int(hex_code[2:4], 16)
            b = int(hex_code[4:6], 16)

            embed = discord.Embed(
                title=f"Color Information: #{hex_code.upper()}",
                color=decimal_color
            )
            embed.add_field(name="Hex", value=f"`#{hex_code.upper()}`", inline=True)
            embed.add_field(name="RGB", value=f"`({r}, {g}, {b})`", inline=True)
            embed.add_field(name="Decimal", value=f"`{decimal_color}`", inline=True)
            embed.set_thumbnail(url=f"https://singlecolorimage.com/get/{hex_code}/400x400")

            await interaction.followup.send(embed=embed)
            logger.info(f"Successfully displayed color info for hex: {hex_code}")
        except Exception as e:
            embed = discord.Embed(
                title="Error",
                description=f"An unexpected error occurred: {e}",
                color=discord.Color.red()
            )
            await interaction.followup.send(embed=embed)
            logger.error(f"Unexpected error while getting color info for hex {hex_code}: {e}", exc_info=True)

    @color_group.error
    async def color_group_error(self, interaction: discord.Interaction, error):
        if isinstance(error, app_commands.MissingPermissions):
            logger.warning(f"User {interaction.user.id} attempted to use a color command without permissions.")
            await interaction.response.send_message("You don't have permission to use this command.", ephemeral=True)
        else:
            logger.error(f"An unexpected error occurred in color_group_error handler for user {interaction.user.id}: {error}", exc_info=True)
            await interaction.response.send_message(f"An unexpected error occurred: {error}", ephemeral=True)

async def setup(bot):
    await bot.add_cog(Color(bot))