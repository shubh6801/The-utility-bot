import discord
from discord.ext import commands
from discord import app_commands
import logging
from datetime import datetime

logger = logging.getLogger(__name__)

class Timestamp(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    timestamp_commands = app_commands.Group(name="timestamp", description="Commands for time conversion utilities.")

    @timestamp_commands.command(name="convert", description="Converts a given time to various Discord timestamp formats.")
    @app_commands.describe(
        time_str="The time string to convert (e.g., '2023-10-27 10:30:00' or '2023-10-27T10:30:00')."
    )
    async def convert_timestamp(self, 
                                interaction: discord.Interaction,
                                time_str: str
                               ):
        """
        Converts the given time string to various Discord timestamp formats.
        """
        await interaction.response.defer()
        try:
            # Attempt to parse the time string. This is a basic example and can be expanded
            # to handle more formats or use a more robust parsing library.
            try:
                dt_object = datetime.fromisoformat(time_str)
            except ValueError:
                # Try parsing with a common format, e.g., 'YYYY-MM-DD HH:MM:SS'
                try:
                    dt_object = datetime.strptime(time_str, "%Y-%m-%d %H:%M:%S")
                except ValueError:
                    await interaction.followup.send("Invalid time format. Please use ISO format (YYYY-MM-DDTHH:MM:SS) or YYYY-MM-DD HH:MM:SS.", ephemeral=True)
                    return

            unix_timestamp = int(dt_object.timestamp())

            embed = discord.Embed(
                title="Timestamp Converter",
                description=f"Original Time: `{time_str}`\n\n" \
                            f"**Discord Timestamp Formats:**\n"
                            f"Short Time: <t:{unix_timestamp}:t> (`<t:{unix_timestamp}:t>`)\n"
                            f"Long Time: <t:{unix_timestamp}:T> (`<t:{unix_timestamp}:T>`)\n"
                            f"Short Date: <t:{unix_timestamp}:d> (`<t:{unix_timestamp}:d>`)\n"
                            f"Long Date: <t:{unix_timestamp}:D> (`<t:{unix_timestamp}:D>`)\n"
                            f"Short Date/Time: <t:{unix_timestamp}:f> (`<t:{unix_timestamp}:f>`)\n"
                            f"Long Date/Time: <t:{unix_timestamp}:F> (`<t:{unix_timestamp}:F>`)\n"
                            f"Relative Time: <t:{unix_timestamp}:R> (`<t:{unix_timestamp}:R>`)",
                color=discord.Color.purple()
            )
            embed.set_footer(text=f"Requested by {interaction.user.display_name}")
            await interaction.followup.send(embed=embed)
            logger.info(f"Timestamp converted for \'{time_str}\' by {interaction.user} in {interaction.guild.name}")

        except Exception as e:
            logger.error(f"Error converting timestamp for \'{time_str}\': {e}", exc_info=True)
            await interaction.followup.send("An error occurred while converting the timestamp. Please try again later.", ephemeral=True)

    @timestamp_commands.error
    async def timestamp_error(self, interaction: discord.Interaction, error):
        if isinstance(error, app_commands.MissingPermissions):
            logger.warning(f"User {interaction.user.id} attempted to use a timestamp command without permissions.")
            await interaction.response.send_message("You don't have permission to use this command.", ephemeral=True)
        else:
            logger.error(f"An unexpected error occurred in timestamp_error handler for user {interaction.user.id}: {error}", exc_info=True)
            await interaction.response.send_message(f"An unexpected error occurred: {error}", ephemeral=True)

async def setup(bot):
    await bot.add_cog(Timestamp(bot))