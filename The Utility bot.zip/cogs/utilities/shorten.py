import logging
import aiohttp
import discord
from discord.ext import commands
from discord import app_commands

logger = logging.getLogger(__name__)

class Shorten(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    shorten = app_commands.Group(name="shorten", description="Commands for URL shortening")

    @shorten.command(name="url", description="Shorten a given URL")
    @app_commands.describe(
        url="The URL to shorten."
    )
    async def shorten_url(self, 
                          interaction: discord.Interaction,
                          url: str
                         ):
        logger.info(f"Received /shorten url command from {interaction.user.name} ({interaction.user.id}) for URL: {url}")
        await interaction.response.defer()

        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(f"http://tinyurl.com/api-create.php?url={url}") as resp:
                    if resp.status == 200:
                        shortened_url = await resp.text()
                        embed = discord.Embed(
                            title="URL Shortened",
                            description=f"Original URL: {url}\nShortened URL: {shortened_url}",
                            color=discord.Color.green()
                        )
                        await interaction.followup.send(embed=embed)
                        logger.info(f"Successfully shortened URL {url} to {shortened_url}")
                    else:
                        embed = discord.Embed(
                            title="Error",
                            description=f"Could not shorten URL. Status: {resp.status}",
                            color=discord.Color.red()
                        )
                        await interaction.followup.send(embed=embed)
                        logger.error(f"Failed to shorten URL {url}. Status: {resp.status}")
        except aiohttp.ClientError as e:
            embed = discord.Embed(
                title="Error",
                description=f"An error occurred while connecting to the URL shortening service: {e}",
                color=discord.Color.red()
            )
            await interaction.followup.send(embed=embed)
            logger.error(f"Aiohttp client error while shortening URL {url}: {e}", exc_info=True)
        except Exception as e:
            embed = discord.Embed(
                title="Error",
                description=f"An unexpected error occurred: {e}",
                color=discord.Color.red()
            )
            await interaction.followup.send(embed=embed)
            logger.error(f"Unexpected error while shortening URL {url}: {e}", exc_info=True)

    @shorten.error
    async def shorten_error(self, interaction: discord.Interaction, error):
        if isinstance(error, app_commands.MissingPermissions):
            logger.warning(f"User {interaction.user.id} attempted to use the shorten command without permissions.")
            await interaction.response.send_message("You don't have permission to use this command.", ephemeral=True)
        else:
            logger.error(f"An unexpected error occurred in shorten_error handler for user {interaction.user.id}: {error}", exc_info=True)
            await interaction.response.send_message(f"An unexpected error occurred: {error}", ephemeral=True)

async def setup(bot):
    await bot.add_cog(Shorten(bot))