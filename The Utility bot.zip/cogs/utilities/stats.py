import discord
from discord.ext import commands
from discord import app_commands
import logging

logger = logging.getLogger(__name__)

class Stats(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="stats", description="Displays server statistics.")
    async def stats(self, interaction: discord.Interaction):
        logger.info(f"Received /stats command from {interaction.user.name} ({interaction.user.id}) in {interaction.guild.name} ({interaction.guild.id})")
        try:
            guild = interaction.guild
            if not guild:
                await interaction.response.send_message("This command can only be used in a server.", ephemeral=True)
                logger.warning(f"[/stats] Command used outside of a guild by {interaction.user.name}")
                return

            member_count = guild.member_count
            text_channels = len(guild.text_channels)
            voice_channels = len(guild.voice_channels)
            roles = len(guild.roles)
            emojis = len(guild.emojis)
            created_at = guild.created_at.strftime("%Y-%m-%d %H:%M:%S UTC")

            embed = discord.Embed(
                title=f"Statistics for {guild.name}",
                color=discord.Color.blue()
            )
            embed.set_thumbnail(url=guild.icon.url if guild.icon else None)
            embed.add_field(name="Members", value=member_count, inline=True)
            embed.add_field(name="Text Channels", value=text_channels, inline=True)
            embed.add_field(name="Voice Channels", value=voice_channels, inline=True)
            embed.add_field(name="Roles", value=roles, inline=True)
            embed.add_field(name="Emojis", value=emojis, inline=True)
            embed.add_field(name="Created On", value=created_at, inline=False)
            embed.set_footer(text=f"Server ID: {guild.id}")

            await interaction.response.send_message(embed=embed)
            logger.info(f"[/stats] Successfully displayed server statistics for {guild.name}")

        except Exception as e:
            logger.error(f"Error in /stats command for {interaction.guild.name} ({interaction.guild.id}): {e}", exc_info=True)
            await interaction.response.send_message("An unexpected error occurred while fetching server statistics. Please try again later.", ephemeral=True)

    @stats.error
    async def stats_error(self, interaction: discord.Interaction, error):
        if isinstance(error, app_commands.MissingPermissions):
            logger.warning(f"User {interaction.user.id} attempted to use the stats command without permissions.")
            await interaction.response.send_message("You don't have permission to use this command.", ephemeral=True)
        else:
            logger.error(f"An unexpected error occurred in stats_error handler for user {interaction.user.id}: {error}", exc_info=True)
            await interaction.response.send_message(f"An unexpected error occurred: {error}", ephemeral=True)

async def setup(bot):
    await bot.add_cog(Stats(bot))