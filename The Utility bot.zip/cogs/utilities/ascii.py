import discord
from discord.ext import commands
from discord import app_commands
import logging
from art import text2art

logger = logging.getLogger(__name__)

class ASCII(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    ascii_group = app_commands.Group(name="ascii", description="Commands for generating ASCII art.")

    @ascii_group.command(name="generate", description="Converts text to ASCII art.")
    async def generate_ascii(self, interaction: discord.Interaction, text: str):
        """
        Converts the given text to ASCII art.
        """
        await interaction.response.defer()
        try:
            if len(text) > 50:
                await interaction.followup.send("Please keep the text under 50 characters to ensure readability.", ephemeral=True)
                return

            ascii_art = text2art(text)
            if len(ascii_art) > 1900:  # Discord message character limit is 2000
                await interaction.followup.send("The generated ASCII art is too large to display. Please try a shorter text.", ephemeral=True)
                return

            embed = discord.Embed(
                title="ASCII Art Generator",
                description=f"```\n{ascii_art}\n```",
                color=discord.Color.blue()
            )
            embed.set_footer(text=f"Requested by {interaction.user.display_name}")
            await interaction.followup.send(embed=embed)
            logger.info(f"ASCII art generated for '{text}' by {interaction.user} in {interaction.guild.name}")

        except Exception as e:
            logger.error(f"Error generating ASCII art for '{text}': {e}", exc_info=True)
            await interaction.followup.send("An error occurred while generating ASCII art. Please try again later.", ephemeral=True)

    @ascii_group.error
    async def ascii_group_error(self, interaction: discord.Interaction, error):
        if isinstance(error, app_commands.MissingPermissions):
            logger.warning(f"User {interaction.user.id} attempted to use an ASCII command without permissions.")
            await interaction.response.send_message("You don't have permission to use this command.", ephemeral=True)
        else:
            logger.error(f"An unexpected error occurred in ascii_group_error handler for user {interaction.user.id}: {error}", exc_info=True)
            await interaction.response.send_message(f"An unexpected error occurred: {error}", ephemeral=True)

async def setup(bot):
    await bot.add_cog(ASCII(bot))