import discord
from discord.ext import commands
from discord import app_commands
import datetime
import logging

logger = logging.getLogger(__name__)

class Uptime(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="uptime", description="Displays the bot's uptime and last restart time.")
    async def uptime(self, interaction: discord.Interaction):
        try:
            delta_uptime = datetime.datetime.utcnow() - self.bot.uptime
            hours, remainder = divmod(int(delta_uptime.total_seconds()), 3600)
            minutes, seconds = divmod(remainder, 60)
            days, hours = divmod(hours, 24)

            embed = discord.Embed(
                title="Bot Uptime",
                description=f"I have been online for: {days}d, {hours}h, {minutes}m, {seconds}s",
                color=discord.Color.blue()
            )
            embed.add_field(name="Last Restart", value=self.bot.uptime.strftime("%Y-%m-%d %H:%M:%S UTC"), inline=False)
            embed.add_field(name="System Time", value=datetime.datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S UTC"), inline=False)
            await interaction.response.send_message(embed=embed)
            logger.info(f"Uptime command used by {interaction.user.name} in {interaction.guild.name}")
        except Exception as e:
            logger.error(f"Error in uptime command for {interaction.user.name} ({interaction.user.id}): {e}", exc_info=True)
            await interaction.response.send_message("An error occurred while trying to get the uptime.", ephemeral=True)

async def setup(bot):
    await bot.add_cog(Uptime(bot))