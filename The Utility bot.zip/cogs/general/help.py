import discord
from discord.ext import commands
from discord import app_commands
import logging

logger = logging.getLogger(__name__)

class Help(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="help", description="Displays a list of all available commands.")
    async def help(self, interaction: discord.Interaction):
        try:
            embed = discord.Embed(title="Bot Commands", description="Here's a list of all available commands and their categories:", color=discord.Color.green())

            for cog_name, cog in self.bot.cogs.items():
                commands_in_cog = []
                for command in cog.get_commands():
                    commands_in_cog.append(f"`/{command.name}` - {command.description or 'No description provided.'}")
                for command in cog.get_app_commands():
                    commands_in_cog.append(f"`/{command.name}` - {command.description or 'No description provided.'}")

                if commands_in_cog:
                    embed.add_field(name=cog_name, value="\n".join(commands_in_cog), inline=False)

            embed.set_footer(text=f"Requested by {interaction.user.display_name}")
            await interaction.response.send_message(embed=embed, ephemeral=True)
            logger.info(f"Help command executed by {interaction.user.name}.")
        except Exception as e:
            logger.error(f"Error in help command: {e}")
            await interaction.response.send_message("An error occurred while trying to display help.", ephemeral=True)

async def setup(bot):
    await bot.add_cog(Help(bot))