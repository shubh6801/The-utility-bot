import discord
from discord import app_commands
from discord.ext import commands
import logging

logger = logging.getLogger(__name__)

class General(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="ping", description="Displays the bot's latency.")
    async def ping(self, interaction: discord.Interaction):
        try:
            api_latency = round(self.bot.latency * 1000)
            websocket_latency = round(self.bot.websocket_latency * 1000)
            await interaction.response.send_message(f"Pong!\nAPI Latency: {api_latency}ms\nWebsocket Latency: {websocket_latency}ms")
            logger.info(f"Ping command executed by {interaction.user.name}. API Latency: {api_latency}ms, Websocket Latency: {websocket_latency}ms")
        except Exception as e:
            logger.error(f"Error in ping command: {e}")
            await interaction.response.send_message("An error occurred while trying to get the bot's latency.", ephemeral=True)

async def setup(bot):
    await bot.add_cog(General(bot))