import discord
from discord import app_commands
from discord.ext import commands
import psutil
import datetime
import platform
import logging

logger = logging.getLogger(__name__)

class BotInfo(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.process = psutil.Process()

    @app_commands.command(name="botinfo", description="Displays information about the bot.")
    async def botinfo(self, interaction: discord.Interaction):
        try:
            # Uptime
            delta_uptime = datetime.datetime.utcnow() - self.bot.uptime
            hours, remainder = divmod(int(delta_uptime.total_seconds()), 3600)
            minutes, seconds = divmod(remainder, 60)
            days, hours = divmod(hours, 24)

            # Memory usage
            memory_usage = self.process.memory_full_info().rss / (1024 ** 2) # in MB

            # Server count
            server_count = len(self.bot.guilds)

            # Command count (approximate, as app_commands don't have a direct count like traditional commands)
            command_count = len(self.bot.tree.get_commands())

            # Library version
            discord_version = discord.__version__

            # Developer information (replace with actual developer info)
            developer_info = "Your Name/Team Name"

            embed = discord.Embed(title="Bot Information", color=discord.Color.blue())
            embed.add_field(name="Uptime", value=f"{days}d {hours}h {minutes}m {seconds}s", inline=True)
            embed.add_field(name="Memory Usage", value=f"{memory_usage:.2f} MB", inline=True)
            embed.add_field(name="Servers", value=server_count, inline=True)
            embed.add_field(name="Commands", value=command_count, inline=True)
            embed.add_field(name="discord.py Version", value=discord_version, inline=True)
            embed.add_field(name="Python Version", value=platform.python_version(), inline=True)
            embed.add_field(name="Developer", value=developer_info, inline=True)
            embed.set_footer(text=f"Bot ID: {self.bot.user.id}")

            await interaction.response.send_message(embed=embed)
            logger.info(f"Botinfo command executed by {interaction.user.name}.")
        except Exception as e:
            logger.error(f"Error in botinfo command: {e}")
            await interaction.response.send_message("An error occurred while trying to get bot information.", ephemeral=True)

async def setup(bot):
    await bot.add_cog(BotInfo(bot))