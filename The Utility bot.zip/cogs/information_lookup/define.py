import discord
from discord.ext import commands
from discord import app_commands
import logging
import aiohttp

logger = logging.getLogger(__name__)

class Define(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="define", description="Get the definition of a word.")
    @app_commands.describe(word="The word to define")
    async def define(self, interaction: discord.Interaction, word: str):
        await interaction.response.defer()

        api_url = f"https://api.dictionaryapi.dev/api/v2/entries/en/{word}"

        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(api_url) as response:
                    data = await response.json()

                    if response.status == 200 and isinstance(data, list) and data:
                        entry = data[0]
                        word_text = entry.get("word", word)
                        phonetic = entry.get("phonetic", "N/A")
                        meanings = entry.get("meanings", [])

                        embed = discord.Embed(
                            title=f"Definition of {word_text.capitalize()}",
                            description=f"Phonetic: {phonetic}",
                            color=discord.Color.green()
                        )

                        for meaning in meanings:
                            part_of_speech = meaning.get("partOfSpeech", "N/A")
                            definitions = meaning.get("definitions", [])
                            if definitions:
                                def_texts = [f"{i+1}. {d['definition']}" for i, d in enumerate(definitions[:3])]
                                embed.add_field(name=f"Part of Speech: {part_of_speech}", value="\n".join(def_texts), inline=False)

                        if not meanings:
                            embed.add_field(name="No Definitions Found", value="Could not find any definitions for this word.", inline=False)

                        await interaction.followup.send(embed=embed)
                        logger.info(f"Successfully fetched definition for {word} by {interaction.user.name}")
                    elif response.status == 404:
                        await interaction.followup.send(f"Could not find a definition for '{word}'. Please check your spelling.", ephemeral=True)
                        logger.warning(f"Definition not found for {word} requested by {interaction.user.name}")
                    else:
                        await interaction.followup.send(f"An error occurred while fetching the definition for '{word}'. Please try again later.", ephemeral=True)
                        logger.error(f"Failed to fetch definition for {word} for {interaction.user.name} ({interaction.user.id}): {data.get('message', 'Unknown error')}", exc_info=True)

        except aiohttp.ClientError as e:
            await interaction.followup.send("An error occurred while connecting to the dictionary service. Please try again later.", ephemeral=True)
            logger.error(f"Aiohttp client error for {interaction.user.name} ({interaction.user.id}): {e}", exc_info=True)
        except Exception as e:
            await interaction.followup.send("An unexpected error occurred. Please try again later.", ephemeral=True)
            logger.error(f"Unexpected error in define command for {interaction.user.name} ({interaction.user.id}): {e}", exc_info=True)

async def setup(bot):
    await bot.add_cog(Define(bot))