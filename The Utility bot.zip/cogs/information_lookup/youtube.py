import discord
from discord import app_commands
from discord.ext import commands
import logging
import os
import aiohttp
from urllib.parse import urlencode

logger = logging.getLogger(__name__)

class YouTube(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.youtube_api_key = os.getenv("YOUTUBE_API_KEY")
        if not self.youtube_api_key:
            logger.error("YOUTUBE_API_KEY environment variable not set.")

    youtube = app_commands.Group(name="youtube", description="Commands for YouTube search.")

    @youtube.command(name="search", description="Search YouTube for videos.")
    async def search(self, interaction: discord.Interaction, query: str):
        if not self.youtube_api_key:
            await interaction.response.send_message("YouTube API key is not configured. Please contact the bot owner.", ephemeral=True)
            return

        await interaction.response.defer()

        base_url = "https://www.googleapis.com/youtube/v3/search"
        params = {
            "part": "snippet",
            "q": query,
            "key": self.youtube_api_key,
            "maxResults": 1,
            "type": "video"
        }
        encoded_params = urlencode(params)
        search_url = f"{base_url}?{encoded_params}"

        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(search_url) as response:
                    if response.status == 200:
                        data = await response.json()
                        if data["items"]:
                            video = data["items"][0]
                            video_id = video["id"]["videoId"]
                            video_title = video["snippet"]["title"]
                            video_description = video["snippet"]["description"]
                            video_thumbnail = video["snippet"]["thumbnails"]["high"]["url"]
                            video_url = f"https://www.youtube.com/watch?v={video_id}"

                            embed = discord.Embed(
                                title=video_title,
                                url=video_url,
                                description=video_description or "No description available.",
                                color=discord.Color.red()
                            )
                            embed.set_image(url=video_thumbnail)
                            embed.set_footer(text="YouTube")

                            await interaction.followup.send(embed=embed)
                        else:
                            await interaction.followup.send(f"No YouTube videos found for `{query}`.")
                    else:
                        logger.error(f"YouTube API request failed with status {response.status} - {await response.text()}")
                        await interaction.followup.send("Failed to retrieve YouTube search results. Please try again later.")
        except Exception as e:
            logger.error(f"Error fetching YouTube search results for '{query}': {e}")
            await interaction.followup.send("An unexpected error occurred while searching YouTube. Please try again later.")

def setup(bot):
    bot.add_cog(YouTube(bot))