import discord
from discord import app_commands
from discord.ext import commands
import asyncpraw
import os
import logging

logger = logging.getLogger(__name__)

class Reddit(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.reddit = asyncpraw.Reddit(
            client_id=os.getenv("REDDIT_CLIENT_ID"),
            client_secret=os.getenv("REDDIT_CLIENT_SECRET"),
            user_agent=os.getenv("REDDIT_USER_AGENT"),
        )

    reddit_group = app_commands.Group(name="reddit", description="Commands for interacting with Reddit.")

    @reddit_group.command(name="subreddit", description="Displays a random hot post from a specified subreddit.")
    async def subreddit(self, interaction: discord.Interaction, subreddit_name: str):
        """
        Displays a random hot post from a specified subreddit.
        """
        await interaction.response.defer()
        try:
            subreddit = await self.reddit.subreddit(subreddit_name)
            posts = []
            async for post in subreddit.hot(limit=50):
                if not post.stickied and not post.over_18:
                    posts.append(post)
            
            if not posts:
                await interaction.followup.send(f"Could not find any suitable posts in r/{subreddit_name}. It might be private, quarantined, or empty.", ephemeral=True)
                return

            post = discord.utils.get(posts, url__contains="i.redd.it") or posts[0] # Prioritize image posts

            embed = discord.Embed(
                title=post.title,
                url=f"https://reddit.com{post.permalink}",
                color=discord.Color.orange()
            )
            embed.set_author(name=f"r/{subreddit_name}", url=f"https://reddit.com/r/{subreddit_name}")
            embed.add_field(name="Author", value=f"u/{post.author.name}", inline=True)
            embed.add_field(name="Score", value=post.score, inline=True)
            embed.add_field(name="Comments", value=post.num_comments, inline=True)
            
            if hasattr(post, 'url_overridden_by_dest') and (post.url_overridden_by_dest.endswith((".jpg", ".png", ".gif", ".jpeg")) or "i.redd.it" in post.url_overridden_by_dest):
                embed.set_image(url=post.url_overridden_by_dest)
            elif post.url.endswith((".jpg", ".png", ".gif", ".jpeg")) or "i.redd.it" in post.url:
                embed.set_image(url=post.url)
            
            await interaction.followup.send(embed=embed)
            logger.info(f"Successfully displayed Reddit post from r/{subreddit_name} for {interaction.user.name}")

        except Exception as e:
            logger.error(f"Error fetching Reddit post for r/{subreddit_name}: {e}")
            await interaction.followup.send(f"An error occurred while trying to fetch a post from r/{subreddit_name}. Please check the subreddit name and try again.", ephemeral=True)

def setup(bot):
    bot.add_cog(Reddit(bot))