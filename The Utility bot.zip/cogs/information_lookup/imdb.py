import discord
from discord.ext import commands
from discord import app_commands
import imdb
import logging

logger = logging.getLogger(__name__)

class IMDB(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.ia = imdb.IMDb()

    imdb_group = app_commands.Group(name="imdb", description="Commands for interacting with IMDb.")

    @imdb_group.command(name="search", description="Searches for movie/TV show information on IMDb.")
    @app_commands.describe(title="The title of the movie or TV show to search for.")
    async def imdb_search(self, interaction: discord.Interaction, title: str):
        await interaction.response.defer()
        try:
            search_results = self.ia.search_movie(title)

            if not search_results:
                await interaction.followup.send(f"Could not find any results for '{title}' on IMDb.", ephemeral=True)
                logger.warning(f"IMDb search for '{title}' by {interaction.user.name} yielded no results.")
                return

            first_result = search_results[0]
            self.ia.update(first_result)

            title_name = first_result.get('title')
            year = first_result.get('year')
            kind = first_result.get('kind')
            plot = self.ia.get_movie(first_result.movieID).get('plot outline')
            rating = first_result.get('rating')
            genres = ', '.join(first_result.get('genres', []))
            directors = ', '.join([d['name'] for d in first_result.get('directors', [])])
            cast = ', '.join([a['name'] for a in first_result.get('cast', [])[:3]]) # Top 3 cast members
            cover_url = first_result.get('cover url')

            embed = discord.Embed(
                title=f"{title_name} ({year})",
                url=f"https://www.imdb.com/title/tt{first_result.movieID}/",
                description=plot,
                color=discord.Color.gold()
            )
            embed.add_field(name="Type", value=kind.capitalize(), inline=True)
            if rating:
                embed.add_field(name="Rating", value=f"{rating}/10", inline=True)
            if genres:
                embed.add_field(name="Genres", value=genres, inline=True)
            if directors:
                embed.add_field(name="Director(s)", value=directors, inline=False)
            if cast:
                embed.add_field(name="Top Cast", value=cast, inline=False)
            if cover_url:
                embed.set_thumbnail(url=cover_url)
            
            await interaction.followup.send(embed=embed)
            logger.info(f"Successfully displayed IMDb info for '{title_name}' for {interaction.user.name}")

        except Exception as e:
            logger.error(f"Error fetching IMDb info for '{title}' for {interaction.user.name} ({interaction.user.id}): {e}", exc_info=True)
            await interaction.followup.send(f"An error occurred while trying to fetch IMDb information for '{title}'. Please try again later.", ephemeral=True)

    @imdb_group.error
    async def imdb_group_error(self, interaction: discord.Interaction, error):
        if isinstance(error, app_commands.CommandInvokeError):
            error = error.original
        logger.error(f"An unexpected error occurred in imdb_group_error handler for user {interaction.user.id}: {error}", exc_info=True)
        await interaction.response.send_message(f"An unexpected error occurred: {error}", ephemeral=True)

async def setup(bot):
    await bot.add_cog(IMDB(bot))