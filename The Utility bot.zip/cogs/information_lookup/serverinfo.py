import discord
from discord import app_commands
from discord.ext import commands
import datetime
import logging

logger = logging.getLogger(__name__)

class ServerInfo(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="serverinfo", description="Displays comprehensive information about the server.")
    async def serverinfo(self, interaction: discord.Interaction):
        try:
            guild = interaction.guild

            if guild is None:
                await interaction.response.send_message("This command can only be used in a server.", ephemeral=True)
                logger.warning(f"Serverinfo command used outside a guild by {interaction.user.name}.")
                return

            # Member count
            total_members = guild.member_count
            online_members = sum(1 for member in guild.members if member.status != discord.Status.offline)

            # Server creation date
            created_at = guild.created_at.strftime("%Y-%m-%d %H:%M:%S UTC")

            # Channel categories and counts
            text_channels = len(guild.text_channels)
            voice_channels = len(guild.voice_channels)
            categories = len(guild.categories)

            # Server boost level
            boost_level = guild.premium_tier
            boost_count = guild.premium_subscription_count

            # Verification level
            verification_level = str(guild.verification_level).replace('_', ' ').title()

            # Explicit content filter level
            explicit_filter = str(guild.explicit_content_filter).replace('_', ' ').title()

            embed = discord.Embed(title=f"Server Information for {guild.name}", color=discord.Color.gold())
            embed.set_thumbnail(url=guild.icon.url if guild.icon else None)
            embed.add_field(name="Owner", value=guild.owner.mention, inline=True)
            embed.add_field(name="Server ID", value=guild.id, inline=True)
            embed.add_field(name="Created On", value=created_at, inline=False)
            embed.add_field(name="Members", value=f"{online_members} Online / {total_members} Total", inline=True)
            embed.add_field(name="Channels", value=f"{text_channels} Text, {voice_channels} Voice ({categories} Categories)", inline=True)
            embed.add_field(name="Boost Level", value=f"Level {boost_level} ({boost_count} Boosts)", inline=True)
            embed.add_field(name="Verification Level", value=verification_level, inline=True)
            embed.add_field(name="Explicit Filter", value=explicit_filter, inline=True)
            embed.set_footer(text=f"Requested by {interaction.user.display_name}")

            await interaction.response.send_message(embed=embed)
            logger.info(f"Serverinfo command executed by {interaction.user.name} in guild {guild.name} ({guild.id}).")
        except Exception as e:
            logger.error(f"Error in serverinfo command: {e}")
            await interaction.response.send_message("An error occurred while trying to get server information.", ephemeral=True)

async def setup(bot):
    await bot.add_cog(ServerInfo(bot))