import discord
from discord.ext import commands
from discord import app_commands
import logging

logger = logging.getLogger(__name__)

class ChannelInfo(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="channelinfo", description="Displays information about a specific channel.")
    @app_commands.describe(
        channel="The channel to get information about (defaults to the current channel)."
    )
    async def channelinfo(self, interaction: discord.Interaction, channel: discord.TextChannel = None):
        if channel is None:
            channel = interaction.channel

        try:
            embed = discord.Embed(title=f"Channel Information: {channel.name}", color=discord.Color.blue())
            embed.add_field(name="ID", value=channel.id, inline=True)
            embed.add_field(name="Type", value=channel.type, inline=True)
            embed.add_field(name="Category", value=channel.category, inline=True)
            embed.add_field(name="Position", value=channel.position, inline=True)
            embed.add_field(name="Created At", value=channel.created_at.strftime("%Y-%m-%d %H:%M:%S UTC"), inline=True)
            embed.add_field(name="NSFW", value=channel.is_nsfw(), inline=True)
            embed.add_field(name="Slowmode Delay", value=f"{channel.slowmode_delay} seconds", inline=True)
            embed.add_field(name="Topic", value=channel.topic if channel.topic else "No topic set", inline=False)

            await interaction.response.send_message(embed=embed)
            logger.info(f"Channel info for channel '{channel.name}' requested by {interaction.user.name} in {interaction.guild.name}")
        except Exception as e:
            logger.error(f"Error displaying channel info for channel '{channel.name}' for {interaction.user.name} ({interaction.user.id}): {e}", exc_info=True)
            await interaction.response.send_message("An error occurred while trying to retrieve channel information. Please try again later.", ephemeral=True)

async def setup(bot):
    await bot.add_cog(ChannelInfo(bot))