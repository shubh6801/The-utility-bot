import discord
from discord import app_commands
from discord.ext import commands
import logging
import aiohttp

logger = logging.getLogger(__name__)

class Urban(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="urban", description="Get the Urban Dictionary definition of a term.")
    async def urban(self, interaction: discord.Interaction, term: str):
        await interaction.response.defer()

        api_url = f"https://api.urbandictionary.com/v0/define?term={term}"

        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(api_url) as response:
                    data = await response.json()

                    if response.status == 200 and data and data["list"]:
                        # Get the first (most popular) definition
                        definition_data = data["list"][0]
                        word = definition_data.get("word", term)
                        definition = definition_data.get("definition", "No definition found.")
                        example = definition_data.get("example", "No example provided.")
                        permalink = definition_data.get("permalink", "https://www.urbandictionary.com/")

                        embed = discord.Embed(
                            title=f"Urban Definition of {word.capitalize()}",
                            url=permalink,
                            description=definition,
                            color=discord.Color.gold()
                        )
                        embed.add_field(name="Example", value=example, inline=False)
                        embed.set_footer(text="Powered by Urban Dictionary")

                        await interaction.followup.send(embed=embed)
                        logger.info(f"Successfully fetched Urban Dictionary definition for {term}")
                    else:
                        await interaction.followup.send(f"Could not find an Urban Dictionary definition for '{term}'.", ephemeral=True)
                        logger.warning(f"Urban Dictionary definition not found for {term}")

        except aiohttp.ClientError as e:
            await interaction.followup.send("An error occurred while connecting to the Urban Dictionary service. Please try again later.", ephemeral=True)
            logger.error(f"Aiohttp client error: {e}")
        except Exception as e:
            await interaction.followup.send("An unexpected error occurred. Please try again later.", ephemeral=True)
            logger.error(f"Unexpected error in urban command: {e}")

def setup(bot):
    bot.add_cog(Urban(bot))