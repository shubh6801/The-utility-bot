import discord
from discord import app_commands
from discord.ext import commands
import logging
import aiohttp
import os

logger = logging.getLogger(__name__)

class Weather(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.api_key = os.getenv("OPENWEATHER_API_KEY") # Ensure you set this environment variable
        if not self.api_key:
            logger.error("OPENWEATHER_API_KEY environment variable not set.")

    @app_commands.command(name="weather", description="Get current weather information for a specified location.")
    async def weather(self, interaction: discord.Interaction, location: str):
        if not self.api_key:
            await interaction.response.send_message("Weather service is not configured. Please contact an administrator.", ephemeral=True)
            return

        await interaction.response.defer()

        base_url = "http://api.openweathermap.org/data/2.5/weather"
        params = {
            "q": location,
            "appid": self.api_key,
            "units": "metric"  # or "imperial" for Fahrenheit
        }

        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(base_url, params=params) as response:
                    data = await response.json()

                    if response.status == 200:
                        main = data["main"]
                        weather_desc = data["weather"][0]
                        wind = data["wind"]
                        city = data["name"]
                        country = data["sys"]["country"]

                        embed = discord.Embed(
                            title=f"Weather in {city}, {country}",
                            description=f"**{weather_desc['description'].capitalize()}**",
                            color=discord.Color.blue()
                        )
                        embed.add_field(name="Temperature", value=f"{main['temp']}°C", inline=True)
                        embed.add_field(name="Feels Like", value=f"{main['feels_like']}°C", inline=True)
                        embed.add_field(name="Humidity", value=f"{main['humidity']}%", inline=True)
                        embed.add_field(name="Wind Speed", value=f"{wind['speed']} m/s", inline=True)
                        embed.add_field(name="Pressure", value=f"{main['pressure']} hPa", inline=True)
                        embed.set_thumbnail(url=f"http://openweathermap.org/img/wn/{weather_desc['icon']}@2x.png")
                        embed.set_footer(text="Powered by OpenWeatherMap")
                        await interaction.followup.send(embed=embed)
                        logger.info(f"Successfully fetched weather for {location}")
                    else:
                        await interaction.followup.send(f"Could not find weather for {location}. Error: {data.get('message', 'Unknown error')}", ephemeral=True)
                        logger.warning(f"Failed to fetch weather for {location}: {data.get('message', 'Unknown error')}")

        except aiohttp.ClientError as e:
            await interaction.followup.send("An error occurred while connecting to the weather service. Please try again later.", ephemeral=True)
            logger.error(f"Aiohttp client error: {e}")
        except Exception as e:
            await interaction.followup.send("An unexpected error occurred. Please try again later.", ephemeral=True)
            logger.error(f"Unexpected error in weather command: {e}")

def setup(bot):
    bot.add_cog(Weather(bot))