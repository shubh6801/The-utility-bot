import discord
from discord import app_commands
from discord.ext import commands
import logging

logger = logging.getLogger(__name__)

class RoleInfo(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="roleinfo", description="Displays information about a specific role.")
    async def roleinfo(self, interaction: discord.Interaction, role: discord.Role):
        """
        Displays information about a specific role.
        """
        try:
            embed = discord.Embed(title=f"Role Information: {role.name}", color=role.color)
            embed.add_field(name="ID", value=role.id, inline=True)
            embed.add_field(name="Members", value=len(role.members), inline=True)
            embed.add_field(name="Color", value=str(role.color), inline=True)
            embed.add_field(name="Hoisted", value=role.hoist, inline=True)
            embed.add_field(name="Mentionable", value=role.mentionable, inline=True)
            embed.add_field(name="Position", value=role.position, inline=True)
            embed.add_field(name="Created At", value=role.created_at.strftime("%Y-%m-%d %H:%M:%S UTC"), inline=True)
            embed.add_field(name="Permissions", value=f"[{len(role.permissions.all())} permissions]", inline=False) # Simplified for brevity
            
            await interaction.response.send_message(embed=embed)
            logger.info(f"Role info for role '{role.name}' requested by {interaction.user} in {interaction.guild}")
        except Exception as e:
            logger.error(f"Error displaying role info for role '{role.name}': {e}")
            await interaction.response.send_message("An error occurred while trying to retrieve role information. Please try again later.", ephemeral=True)

def setup(bot):
    bot.add_cog(RoleInfo(bot))