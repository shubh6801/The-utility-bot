import discord
from discord import app_commands
from discord.ext import commands
import logging

logger = logging.getLogger(__name__)

class Invite(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="invite", description="Generates an invite link for the bot.")
    async def invite(self, interaction: discord.Interaction):
        """
        Generates an invite link for the bot.
        """
        try:
            # You might want to customize permissions based on your bot's needs
            permissions = discord.Permissions()
            permissions.update(send_messages=True, read_messages=True, embed_links=True)
            
            invite_link = discord.utils.oauth_url(self.bot.user.id, permissions=permissions)
            
            embed = discord.Embed(title="Invite Me!", description=f"Click [here]({invite_link}) to invite me to your server!", color=discord.Color.green())
            await interaction.response.send_message(embed=embed, ephemeral=True)
            logger.info(f"Invite link requested by {interaction.user} in {interaction.guild}")
        except Exception as e:
            logger.error(f"Error generating invite link: {e}")
            await interaction.response.send_message("An error occurred while trying to generate the invite link. Please try again later.", ephemeral=True)

def setup(bot):
    bot.add_cog(Invite(bot))