import discord
from discord import app_commands
from discord.ext import commands
import datetime
import logging

logger = logging.getLogger(__name__)

class UserInfo(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="userinfo", description="Displays detailed information about a user.")
    async def userinfo(self, interaction: discord.Interaction, user: discord.Member = None):
        try:
            if user is None:
                user = interaction.user

            embed = discord.Embed(title=f"User Information for {user.display_name}", color=user.color)
            embed.set_thumbnail(url=user.avatar.url if user.avatar else None)

            # Account creation date
            embed.add_field(name="Account Created", value=user.created_at.strftime("%Y-%m-%d %H:%M:%S UTC"), inline=False)

            # Server join date
            if user.joined_at:
                embed.add_field(name="Joined Server", value=user.joined_at.strftime("%Y-%m-%d %H:%M:%S UTC"), inline=False)

            # Roles
            roles = [role.mention for role in user.roles if role.name != "@everyone"]
            if roles:
                embed.add_field(name="Roles", value=", ".join(roles), inline=False)

            # Status
            embed.add_field(name="Status", value=str(user.status).capitalize(), inline=True)

            # Activity
            if user.activity:
                activity_name = user.activity.name
                activity_type = str(user.activity.type).split('.')[-1].capitalize()
                embed.add_field(name="Activity", value=f"{activity_type}: {activity_name}", inline=True)

            embed.set_footer(text=f"User ID: {user.id}")
            await interaction.response.send_message(embed=embed)
            logger.info(f"Userinfo command executed by {interaction.user.name} for user {user.name} ({user.id}).")
        except Exception as e:
            logger.error(f"Error in userinfo command: {e}")
            await interaction.response.send_message("An error occurred while trying to get user information.", ephemeral=True)

async def setup(bot):
    await bot.add_cog(UserInfo(bot))