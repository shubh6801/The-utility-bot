import discord
from discord import app_commands
from discord.ext import commands
import logging
import os
import aiohttp

logger = logging.getLogger(__name__)

class Twitch(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.twitch_client_id = os.getenv("TWITCH_CLIENT_ID")
        self.twitch_client_secret = os.getenv("TWITCH_CLIENT_SECRET")
        self.twitch_access_token = None

        if not self.twitch_client_id or not self.twitch_client_secret:
            logger.error("TWITCH_CLIENT_ID or TWITCH_CLIENT_SECRET environment variables not set.")

    async def get_twitch_access_token(self):
        if self.twitch_access_token:
            return self.twitch_access_token

        token_url = "https://id.twitch.tv/oauth2/token"
        params = {
            "client_id": self.twitch_client_id,
            "client_secret": self.twitch_client_secret,
            "grant_type": "client_credentials"
        }
        async with aiohttp.ClientSession() as session:
            async with session.post(token_url, data=params) as response:
                if response.status == 200:
                    data = await response.json()
                    self.twitch_access_token = data["access_token"]
                    return self.twitch_access_token
                else:
                    logger.error(f"Failed to get Twitch access token: {response.status} - {await response.text()}")
                    return None

    twitch_group = app_commands.Group(name="twitch", description="Commands for Twitch channel information.")

    @twitch_group.command(name="channel", description="Get details for a Twitch channel.")
    async def channel(self, interaction: discord.Interaction, channel_name: str):
        if not self.twitch_client_id or not self.twitch_client_secret:
            await interaction.response.send_message("Twitch API credentials are not configured. Please contact the bot owner.", ephemeral=True)
            return

        await interaction.response.defer()

        access_token = await self.get_twitch_access_token()
        if not access_token:
            await interaction.followup.send("Failed to authenticate with Twitch API. Please try again later.")
            return

        headers = {
            "Client-ID": self.twitch_client_id,
            "Authorization": f"Bearer {access_token}"
        }

        try:
            # Get user information
            user_url = f"https://api.twitch.tv/helix/users?login={channel_name}"
            async with aiohttp.ClientSession() as session:
                async with session.get(user_url, headers=headers) as response:
                    if response.status == 200:
                        user_data = await response.json()
                        if not user_data["data"]:
                            await interaction.followup.send(f"Could not find Twitch channel `{channel_name}`.")
                            return
                        user = user_data["data"][0]
                    else:
                        logger.error(f"Twitch API user request failed with status {response.status} - {await response.text()}")
                        await interaction.followup.send("Failed to retrieve Twitch user data. Please try again later.")
                        return

            # Get stream information
            stream_url = f"https://api.twitch.tv/helix/streams?user_login={channel_name}"
            async with aiohttp.ClientSession() as session:
                async with session.get(stream_url, headers=headers) as response:
                    if response.status == 200:
                        stream_data = await response.json()
                        stream = stream_data["data"][0] if stream_data["data"] else None
                    else:
                        logger.error(f"Twitch API stream request failed with status {response.status} - {await response.text()}")
                        stream = None # Proceed without stream data if request fails

            embed = discord.Embed(
                title=f"{user['display_name']}",
                url=f"https://www.twitch.tv/{user['login']}",
                color=discord.Color.purple()
            )
            embed.set_thumbnail(url=user['profile_image_url'])
            embed.add_field(name="Description", value=user['description'] or "No description.", inline=False)
            embed.add_field(name="Followers", value=f"{user['view_count']:,}", inline=True) # view_count is actually total views for the channel

            if stream:
                embed.add_field(name="Status", value="Live", inline=True)
                embed.add_field(name="Game", value=stream['game_name'], inline=True)
                embed.add_field(name="Viewers", value=f"{stream['viewer_count']:,}", inline=True)
                embed.add_field(name="Stream Title", value=stream['title'], inline=False)
                embed.set_image(url=stream['thumbnail_url'].replace('{width}', '1280').replace('{height}', '720'))
            else:
                embed.add_field(name="Status", value="Offline", inline=True)

            await interaction.followup.send(embed=embed)

        except Exception as e:
            logger.error(f"Error fetching Twitch channel details for '{channel_name}': {e}")
            await interaction.followup.send("An unexpected error occurred while fetching Twitch channel details. Please try again later.")

def setup(bot):
    bot.add_cog(Twitch(bot))