import discord
from discord import app_commands
from discord.ext import commands
import logging
import os
import aiohttp

logger = logging.getLogger(__name__)

class Steam(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.steam_api_key = os.getenv("STEAM_API_KEY")
        if not self.steam_api_key:
            logger.error("STEAM_API_KEY environment variable not set.")

    steam_group = app_commands.Group(name="steam", description="Commands for Steam game information.")

    @steam_group.command(name="game", description="Get details for a Steam game.")
    async def game(self, interaction: discord.Interaction, game_name: str):
        if not self.steam_api_key:
            await interaction.response.send_message("Steam API key is not configured. Please contact the bot owner.", ephemeral=True)
            return

        await interaction.response.defer()

        try:
            # Search for the game to get its App ID
            search_url = f"http://api.steampowered.com/ISteamApps/GetAppList/v2/"
            async with aiohttp.ClientSession() as session:
                async with session.get(search_url) as response:
                    if response.status == 200:
                        data = await response.json()
                        app_list = data["applist"]["apps"]
                        app_id = None
                        for app in app_list:
                            if app["name"].lower() == game_name.lower():
                                app_id = app["app_id"]
                                break
                        
                        if not app_id:
                            await interaction.followup.send(f"Could not find a Steam game named `{game_name}`.")
                            return

            # Get game details using the App ID
            details_url = f"https://store.steampowered.com/api/appdetails?appids={app_id}"
            async with aiohttp.ClientSession() as session:
                async with session.get(details_url) as response:
                    if response.status == 200:
                        data = await response.json()
                        if data and str(app_id) in data and data[str(app_id)]["success"]:
                            game_data = data[str(app_id)]["data"]

                            embed = discord.Embed(
                                title=game_data.get("name", "N/A"),
                                description=game_data.get("short_description", "No description available."),
                                color=discord.Color.blue()
                            )
                            embed.set_thumbnail(url=game_data.get("header_image"))
                            embed.add_field(name="Price", value=game_data["price_overview"]["final_formatted"] if "price_overview" in game_data else "Free" if game_data.get("is_free") else "N/A", inline=True)
                            embed.add_field(name="Release Date", value=game_data["release_date"]["date"] if "release_date" in game_data else "N/A", inline=True)
                            embed.add_field(name="Developers", value=", ".join(game_data.get("developers", ["N/A"])), inline=True)
                            embed.add_field(name="Publishers", value=", ".join(game_data.get("publishers", ["N/A"])), inline=True)
                            embed.add_field(name="Metacritic Score", value=game_data["metacritic"]["score"] if "metacritic" in game_data else "N/A", inline=True)
                            embed.add_field(name="Platforms", value=", ".join([platform for platform, supported in game_data["platforms"].items() if supported]) if "platforms" in game_data else "N/A", inline=True)
                            embed.add_field(name="Store Page", value=f"[Link](https://store.steampowered.com/app/{app_id}/)", inline=False)

                            await interaction.followup.send(embed=embed)
                        else:
                            await interaction.followup.send(f"Could not retrieve details for `{game_name}`. It might not be a valid game or there was an API issue.")
                    else:
                        logger.error(f"Steam API details request failed with status {response.status} for App ID {app_id}")
                        await interaction.followup.send("Failed to retrieve game details from Steam API. Please try again later.")
        except Exception as e:
            logger.error(f"Error fetching Steam game details for '{game_name}': {e}")
            await interaction.followup.send("An unexpected error occurred while fetching Steam game details. Please try again later.")

def setup(bot):
    bot.add_cog(Steam(bot))