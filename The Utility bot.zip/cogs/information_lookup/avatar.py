import discord
from discord.ext import commands
from discord import app_commands
import logging

logger = logging.getLogger(__name__)

class Avatar(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="avatar", description="Displays the full-resolution avatar of a user.")
    @app_commands.describe(
        user="The user whose avatar you want to display (defaults to yourself)."
    )
    async def avatar(self, interaction: discord.Interaction, user: discord.Member = None):
        if user is None:
            user = interaction.user
        try:
            avatar_url = user.avatar.url if user.avatar else user.default_avatar.url
            embed = discord.Embed(
                title=f"{user.display_name}'s Avatar",
                color=discord.Color.blue()
            )
            embed.set_image(url=avatar_url)
            embed.set_footer(text=f"Requested by {interaction.user.display_name}")
            await interaction.response.send_message(embed=embed)
            logger.info(f"Avatar command used by {interaction.user.name} for {user.name} in {interaction.guild.name}")
        except Exception as e:
            logger.error(f"Error in avatar command for {interaction.user.name} ({interaction.user.id}): {e}", exc_info=True)
            await interaction.response.send_message("An error occurred while trying to get the avatar.", ephemeral=True)

async def setup(bot):
    await bot.add_cog(Avatar(bot))