import discord
from discord.ext import commands
from discord import app_commands
import logging
import json
import os
from collections import defaultdict

logger = logging.getLogger(__name__)

class Warn(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.warnings_file = "config/warnings.json"
        self.warnings_data = defaultdict(list)
        self._load_warnings()

    def _load_warnings(self):
        if os.path.exists(self.warnings_file):
            with open(self.warnings_file, 'r') as f:
                data = json.load(f)
                for user_id, warns in data.items():
                    self.warnings_data[int(user_id)] = warns
        logger.info("Warnings loaded successfully.")

    def _save_warnings(self):
        with open(self.warnings_file, 'w') as f:
            json.dump({str(k): v for k, v in self.warnings_data.items()}, f, indent=4)
        logger.info("Warnings saved successfully.")

    @app_commands.command(name="warn", description="Warn a user for a specified reason.")
    @app_commands.checks.has_permissions(kick_members=True)
    async def warn(self, interaction: discord.Interaction, user: discord.Member, reason: str = "No reason provided."):
        """
        Warns a user and logs the action.
        """
        await interaction.response.defer(ephemeral=True)
        try:
            # Log the warning action
            logger.info(f"User {interaction.user} warned {user} for: {reason} in guild {interaction.guild.id}")

            # Send a DM to the warned user
            try:
                await user.send(f"You have been warned in {interaction.guild.name} for: {reason}")
            except discord.Forbidden:
                logger.warning(f"Could not send DM to {user.name}. User might have DMs disabled.")
                await interaction.followup.send(f"Warned {user.mention} for: {reason}. Could not DM user.", ephemeral=True)
                return

            # Send confirmation to the channel
            await interaction.followup.send(f"{user.mention} has been warned for: {reason}", ephemeral=True)

            # Store the warning persistently
            self.warnings_data[user.id].append(f"Warned by {interaction.user.display_name} for: {reason}")
            self._save_warnings()
            logger.info(f"Warning for {user.id} stored persistently.")

        except discord.Forbidden:
            logger.warning(f"Bot lacks permissions to warn user {user.id} in guild {interaction.guild.id}")
            await interaction.followup.send("I do not have permission to warn members.", ephemeral=True)
        except Exception as e:
            logger.error(f"Error warning user {user.id} in guild {interaction.guild.id}: {e}", exc_info=True)
            await interaction.followup.send("An unexpected error occurred while trying to warn the user.", ephemeral=True)

    @warn.error
    async def warn_error(self, interaction: discord.Interaction, error):
        if isinstance(error, app_commands.MissingPermissions):
            logger.warning(f"User {interaction.user.id} attempted to use warn command without permissions.")
            await interaction.response.send_message("You don't have permission to use this command.", ephemeral=True)
        else:
            logger.error(f"An unexpected error occurred in warn_error handler for user {interaction.user.id}: {error}", exc_info=True)
            await interaction.response.send_message(f"An unexpected error occurred: {error}", ephemeral=True)

async def setup(bot):
    await bot.add_cog(Warn(bot))