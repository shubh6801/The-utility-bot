import discord
from discord.ext import commands
from discord import app_commands
import logging

logger = logging.getLogger(__name__)

class Slowmode(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="slowmode", description="Set slowmode for the current channel.")
    @app_commands.checks.has_permissions(manage_channels=True)
    async def slowmode(self, interaction: discord.Interaction, seconds: int):
        """
        Sets the slowmode delay for the current channel.
        """
        await interaction.response.defer(ephemeral=True)
        try:
            if seconds < 0 or seconds > 21600:
                await interaction.followup.send("Slowmode seconds must be between 0 and 21600 (6 hours).", ephemeral=True)
                logger.warning(f"Slowmode command by {interaction.user.id} with invalid amount: {seconds}")
                return

            await interaction.channel.edit(slowmode_delay=seconds)
            logger.info(f"Slowmode set to {seconds} seconds in channel {interaction.channel.id} by {interaction.user.id}")
            if seconds == 0:
                await interaction.followup.send("Slowmode has been disabled for this channel.", ephemeral=True)
            else:
                await interaction.followup.send(f"Slowmode set to {seconds} seconds for this channel.", ephemeral=True)

        except discord.Forbidden:
            logger.warning(f"Bot lacks permissions to set slowmode in channel {interaction.channel.id} for user {interaction.user.id}")
            await interaction.followup.send("I do not have permission to manage channels.", ephemeral=True)
        except Exception as e:
            logger.error(f"Error setting slowmode in channel {interaction.channel.id} in guild {interaction.guild.id}: {e}", exc_info=True)
            await interaction.followup.send("An unexpected error occurred while trying to set slowmode.", ephemeral=True)

    @slowmode.error
    async def slowmode_error(self, interaction: discord.Interaction, error):
        if isinstance(error, app_commands.MissingPermissions):
            logger.warning(f"User {interaction.user.id} attempted to use slowmode command without permissions.")
            await interaction.response.send_message("You don't have permission to use this command.", ephemeral=True)
        else:
            logger.error(f"An unexpected error occurred in slowmode_error handler for user {interaction.user.id}: {error}", exc_info=True)
            await interaction.response.send_message(f"An unexpected error occurred: {error}", ephemeral=True)

async def setup(bot):
    await bot.add_cog(Slowmode(bot))