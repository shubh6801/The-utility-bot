import discord
from discord import app_commands
from discord.ext import commands
import logging

logger = logging.getLogger(__name__)

class Ban(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="ban", description="Bans a user from the server.")
    @app_commands.checks.has_permissions(ban_members=True)
    async def ban(self, interaction: discord.Interaction, user: discord.Member, reason: str = "No reason provided."):
        try:
            if user.id == interaction.user.id:
                await interaction.response.send_message("You cannot ban yourself!", ephemeral=True)
                logger.warning(f"User {interaction.user.name} ({interaction.user.id}) tried to ban themselves.")
                return
            if user.id == self.bot.user.id:
                await interaction.response.send_message("I cannot ban myself!", ephemeral=True)
                logger.warning(f"User {interaction.user.name} ({interaction.user.id}) tried to make the bot ban itself.")
                return
            if user.top_role >= interaction.user.top_role and interaction.user.id != interaction.guild.owner_id:
                await interaction.response.send_message("You cannot ban someone with an equal or higher role than yourself.", ephemeral=True)
                logger.warning(f"User {interaction.user.name} ({interaction.user.id}) tried to ban {user.name} ({user.id}) who has an equal or higher role.")
                return
            if user.top_role >= interaction.guild.me.top_role:
                await interaction.response.send_message("I cannot ban someone with an equal or higher role than myself.", ephemeral=True)
                logger.warning(f"Bot tried to ban {user.name} ({user.id}) who has an equal or higher role than the bot.")
                return

            await user.ban(reason=reason)
            embed = discord.Embed(title="User Banned", color=discord.Color.red())
            embed.add_field(name="User", value=user.mention, inline=True)
            embed.add_field(name="Moderator", value=interaction.user.mention, inline=True)
            embed.add_field(name="Reason", value=reason, inline=False)
            await interaction.response.send_message(embed=embed)
            logger.info(f"User {user.name} ({user.id}) banned by {interaction.user.name} ({interaction.user.id}) for reason: {reason}.")
        except discord.Forbidden:
            await interaction.response.send_message("I do not have permission to ban this user.", ephemeral=True)
            logger.error(f"Bot lacked permissions to ban user {user.name} ({user.id}).")
        except Exception as e:
            await interaction.response.send_message(f"An error occurred: {e}", ephemeral=True)
            logger.error(f"Error in ban command for user {user.name} ({user.id}): {e}")

    @ban.error
    async def ban_error(self, interaction: discord.Interaction, error):
        if isinstance(error, app_commands.MissingPermissions):
            await interaction.response.send_message("You don't have the necessary permissions to ban members.", ephemeral=True)
            logger.warning(f"User {interaction.user.name} ({interaction.user.id}) tried to use ban command without permissions.")
        else:
            await interaction.response.send_message(f"An error occurred: {error}", ephemeral=True)
            logger.error(f"Unhandled error in ban command: {error}")

async def setup(bot):
    await bot.add_cog(Ban(bot))