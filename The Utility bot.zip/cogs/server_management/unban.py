import discord
from discord.ext import commands
from discord import app_commands
import logging

logger = logging.getLogger(__name__)

class Unban(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="unban", description="Unbans a user from the server.")
    @app_commands.describe(user_id="The ID of the user to unban.", reason="The reason for the unban.")
    @commands.has_permissions(ban_members=True)
    async def unban(self, interaction: discord.Interaction, user_id: str, reason: str = "No reason provided."):
        await interaction.response.defer(ephemeral=True)

        try:
            try:
                user = await self.bot.fetch_user(int(user_id))
            except ValueError:
                await interaction.followup.send("Invalid user ID. Please provide a valid numerical user ID.")
                logger.warning(f"Unban command used with invalid user ID: {user_id} by {interaction.user.name}.")
                return
            except discord.NotFound:
                await interaction.followup.send("User not found. Please ensure the ID is correct.")
                logger.warning(f"Unban command used for non-existent user ID: {user_id} by {interaction.user.name}.")
                return

            await interaction.guild.unban(user, reason=reason)
            embed = discord.Embed(
                title="User Unbanned",
                description=f"Successfully unbanned {user.mention} (ID: `{user.id}`).",
                color=discord.Color.green()
            )
            embed.add_field(name="Reason", value=reason, inline=False)
            embed.set_footer(text=f"Unbanned by {interaction.user.display_name}")
            await interaction.followup.send(embed=embed)
            logger.info(f"User {user.name} ({user.id}) unbanned by {interaction.user.name} ({interaction.user.id}) for reason: {reason}.")
        except discord.Forbidden:
            await interaction.followup.send("I do not have permission to unban members.")
            logger.error(f"Bot lacked permissions to unban user ID {user_id}.")
        except Exception as e:
            await interaction.followup.send(f"An error occurred while trying to unban the user: {e}")
            logger.error(f"Error in unban command for user ID {user_id}: {e}")

async def setup(bot):
    await bot.add_cog(Unban(bot))