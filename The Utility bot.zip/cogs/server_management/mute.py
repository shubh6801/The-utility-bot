import discord
from discord.ext import commands
from discord import app_commands
import logging

logger = logging.getLogger(__name__)

class Mute(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="mute", description="Mutes a user in the server.")
    @app_commands.describe(member="The member to mute.", duration="Duration of the mute (e.g., 1h, 30m, 7d).", reason="The reason for the mute.")
    @commands.has_permissions(moderate_members=True)
    async def mute(self, interaction: discord.Interaction, member: discord.Member, duration: str, reason: str = "No reason provided."):
        await interaction.response.defer(ephemeral=True)

        try:
            if member == interaction.user:
                await interaction.followup.send("You cannot mute yourself.")
                logger.warning(f"Self-mute attempt by {interaction.user.name} ({interaction.user.id}).")
                return

            if member.top_role >= interaction.user.top_role and interaction.user.id != interaction.guild.owner_id:
                await interaction.followup.send("You cannot mute someone with an equal or higher role than yourself.")
                logger.warning(f"Mute attempt on higher/equal role member {member.name} ({member.id}) by {interaction.user.name} ({interaction.user.id}).")
                return

            if not interaction.guild.me.guild_permissions.moderate_members:
                await interaction.followup.send("I do not have permission to moderate members (timeout). Please check my permissions.")
                logger.error(f"Bot lacked permissions to moderate members in guild {interaction.guild.name} ({interaction.guild.id}).")
                return

            # Parse duration
            seconds = 0
            try:
                if duration.endswith('s'):
                    seconds = int(duration[:-1])
                elif duration.endswith('m'):
                    seconds = int(duration[:-1]) * 60
                elif duration.endswith('h'):
                    seconds = int(duration[:-1]) * 3600
                elif duration.endswith('d'):
                    seconds = int(duration[:-1]) * 86400
                else:
                    await interaction.followup.send("Invalid duration format. Use 's' for seconds, 'm' for minutes, 'h' for hours, or 'd' for days (e.g., `30m`, `1h`, `7d`).")
                    logger.warning(f"Invalid mute duration format '{duration}' by {interaction.user.name} ({interaction.user.id}).")
                    return
            except ValueError:
                await interaction.followup.send("Invalid duration value. Please provide a number followed by 's', 'm', 'h', or 'd'.")
                logger.warning(f"Invalid mute duration value '{duration}' by {interaction.user.name} ({interaction.user.id}).")
                return

            if seconds <= 0:
                await interaction.followup.send("Duration must be a positive value.")
                logger.warning(f"Mute duration must be positive. Provided: {duration} by {interaction.user.name} ({interaction.user.id}).")
                return

            # Discord timeout limit is 28 days (2419200 seconds)
            if seconds > 2419200:
                await interaction.followup.send("The maximum timeout duration is 28 days.")
                logger.warning(f"Mute duration {duration} exceeds 28 days limit by {interaction.user.name} ({interaction.user.id}).")
                return

            await member.timeout(discord.utils.utcnow() + discord.timedelta(seconds=seconds), reason=reason)
            embed = discord.Embed(
                title="User Muted",
                description=f"Successfully muted {member.mention} (ID: `{member.id}`).",
                color=discord.Color.red()
            )
            embed.add_field(name="Duration", value=duration, inline=True)
            embed.add_field(name="Reason", value=reason, inline=False)
            embed.set_footer(text=f"Muted by {interaction.user.display_name}")
            await interaction.followup.send(embed=embed)
            logger.info(f"Member {member.name} ({member.id}) muted by {interaction.user.name} ({interaction.user.id}) for {duration} with reason: {reason}.")
        except discord.Forbidden:
            await interaction.followup.send("I do not have permission to mute members.")
            logger.error(f"Bot lacked permissions to mute member {member.name} ({member.id}).")
        except Exception as e:
            await interaction.followup.send(f"An error occurred while trying to mute the user: {e}")
            logger.error(f"Error in mute command for member {member.name} ({member.id}): {e}")

async def setup(bot):
    await bot.add_cog(Mute(bot))