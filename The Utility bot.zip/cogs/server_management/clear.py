import discord
from discord import app_commands
from discord.ext import commands
import logging

logger = logging.getLogger(__name__)

class Clear(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="clear", description="Clears a specified number of messages from the channel.")
    @app_commands.describe(amount="The number of messages to clear (1-100).")
    @app_commands.checks.has_permissions(manage_messages=True)
    async def clear(self, interaction: discord.Interaction, amount: int):
        try:
            if not interaction.guild:
                logger.warning(f"Clear command used outside of a guild by {interaction.user.id}")
                await interaction.response.send_message("This command can only be used in a server.", ephemeral=True)
                return

            if not 1 <= amount <= 100:
                logger.warning(f"Clear command by {interaction.user.id} with invalid amount: {amount}")
                await interaction.response.send_message("You can only clear between 1 and 100 messages.", ephemeral=True)
                return

            await interaction.response.defer(ephemeral=True)
            deleted_messages = await interaction.channel.purge(limit=amount)
            logger.info(f"Cleared {len(deleted_messages)} messages in channel {interaction.channel.id} by {interaction.user.id}")
            await interaction.followup.send(f"Successfully cleared {len(deleted_messages)} messages.", ephemeral=True)
        except discord.Forbidden:
            logger.error(f"Bot lacks permissions to clear messages in channel {interaction.channel.id} for user {interaction.user.id}")
            await interaction.followup.send("I do not have permission to delete messages in this channel.", ephemeral=True)
        except Exception as e:
            logger.error(f"An error occurred during clear command for user {interaction.user.id}: {e}", exc_info=True)
            await interaction.followup.send(f"An error occurred: {e}", ephemeral=True)

    @clear.error
    async def clear_error(self, interaction: discord.Interaction, error):
        if isinstance(error, app_commands.MissingPermissions):
            logger.warning(f"User {interaction.user.id} attempted to use clear command without permissions.")
            await interaction.response.send_message("You don't have permission to use this command.", ephemeral=True)
        else:
            logger.error(f"An unexpected error occurred in clear_error handler for user {interaction.user.id}: {error}", exc_info=True)
            await interaction.response.send_message(f"An unexpected error occurred: {error}", ephemeral=True)

async def setup(bot):
    await bot.add_cog(Clear(bot))