import discord
from discord.ext import commands
from discord import app_commands
import logging
import json
import os
from collections import defaultdict

logger = logging.getLogger(__name__)

class Warnings(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.warnings_file = "config/warnings.json"
        self.warnings_data = defaultdict(list)
        self._load_warnings()

    def _load_warnings(self):
        if os.path.exists(self.warnings_file):
            with open(self.warnings_file, 'r') as f:
                data = json.load(f)
                for user_id, warns in data.items():
                    self.warnings_data[int(user_id)] = warns
        logger.info("Warnings loaded successfully.")

    @app_commands.command(name="warnings", description="Check a user's warnings.")
    @app_commands.checks.has_permissions(kick_members=True)
    async def warnings(self, interaction: discord.Interaction, user: discord.Member):
        """
        Displays a user's warnings.
        """
        await interaction.response.defer(ephemeral=True)
        try:
            # Log the action
            logger.info(f"User {interaction.user} checked warnings for {user} in guild {interaction.guild.id}")

            user_warnings = self.warnings_data.get(user.id, [])

            if not user_warnings:
                await interaction.followup.send(f"{user.mention} has no warnings.", ephemeral=True)
                return

            embed = discord.Embed(
                title=f"Warnings for {user.display_name}",
                color=discord.Color.orange()
            )
            for i, warning in enumerate(user_warnings, 1):
                embed.add_field(name=f"Warning {i}", value=warning, inline=False)

            await interaction.followup.send(embed=embed, ephemeral=True)

        except discord.Forbidden:
            logger.warning(f"Bot lacks permissions to view warnings for user {user.id} in guild {interaction.guild.id}")
            await interaction.followup.send("I do not have permission to view warnings.", ephemeral=True)
        except Exception as e:
            logger.error(f"Error checking warnings for user {user.id} in guild {interaction.guild.id}: {e}", exc_info=True)
            await interaction.followup.send("An unexpected error occurred while trying to retrieve warnings.", ephemeral=True)

    @warnings.error
    async def warnings_error(self, interaction: discord.Interaction, error):
        if isinstance(error, app_commands.MissingPermissions):
            logger.warning(f"User {interaction.user.id} attempted to use warnings command without permissions.")
            await interaction.response.send_message("You don't have permission to use this command.", ephemeral=True)
        else:
            logger.error(f"An unexpected error occurred in warnings_error handler for user {interaction.user.id}: {error}", exc_info=True)
            await interaction.response.send_message(f"An unexpected error occurred: {error}", ephemeral=True)

async def setup(bot):
    await bot.add_cog(Warnings(bot))