import discord
from discord import app_commands
from discord.ext import commands
import logging
import json

logger = logging.getLogger(__name__)

CONFIG_PATH = "config/goodbye_messages.json"

class Goodbye(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.logger = logging.getLogger(__name__)
        self.goodbye_configs = self._load_goodbye_configs()

    def _load_goodbye_configs(self):
        try:
            with open(CONFIG_PATH, 'r') as f:
                return {int(k): v for k, v in json.load(f).items()}
        except FileNotFoundError:
            return {}
        except json.JSONDecodeError:
            self.logger.error(f"Error decoding JSON from {CONFIG_PATH}. Returning empty goodbye configs.")
            return {}

    def _save_goodbye_configs(self):
        with open(CONFIG_PATH, 'w') as f:
            json.dump(self.goodbye_configs, f, indent=4)

    server = app_commands.Group(name="server", description="Server management commands")

    @server.command(name="set_goodbye_message", description="Sets up the goodbye message for departing members.")
    @app_commands.describe(message="The goodbye message to set. Use {member} for mention, {server} for server name.")
    @commands.has_permissions(manage_guild=True)
    async def set_goodbye_message(self, interaction: discord.Interaction, message: str):
        try:
            guild_id = str(interaction.guild.id)
            if guild_id not in self.goodbye_configs:
                self.goodbye_configs[guild_id] = {}
            self.goodbye_configs[guild_id]["message"] = message
            self._save_goodbye_configs()
            logger.info(f"Goodbye message set by {interaction.user.name} in {interaction.guild.name}: {message}")
            await interaction.response.send_message(f"Goodbye message has been set to: ```{message}```", ephemeral=True)
        except Exception as e:
            logger.error(f"Error setting goodbye message: {e}")
            await interaction.response.send_message("An error occurred while setting the goodbye message.", ephemeral=True)

    @server.command(name="set_goodbye_channel", description="Sets the channel where goodbye messages will be sent.")
    @app_commands.describe(channel="The channel to send goodbye messages to.")
    @commands.has_permissions(manage_guild=True)
    async def set_goodbye_channel(self, interaction: discord.Interaction, channel: discord.TextChannel):
        try:
            guild_id = str(interaction.guild.id)
            if guild_id not in self.goodbye_configs:
                self.goodbye_configs[guild_id] = {}
            self.goodbye_configs[guild_id]["channel_id"] = channel.id
            self._save_goodbye_configs()
            logger.info(f"Goodbye channel set by {interaction.user.name} in {interaction.guild.name}: {channel.name}")
            await interaction.response.send_message(f"Goodbye messages will now be sent to {channel.mention}.", ephemeral=True)
        except Exception as e:
            logger.error(f"Error setting goodbye channel: {e}")
            await interaction.response.send_message("An error occurred while setting the goodbye channel.", ephemeral=True)

    @commands.Cog.listener()
    async def on_member_remove(self, member: discord.Member):
        guild_id = str(member.guild.id)
        if guild_id in self.goodbye_configs and "message" in self.goodbye_configs[guild_id] and "channel_id" in self.goodbye_configs[guild_id]:
            goodbye_message = self.goodbye_configs[guild_id]["message"]
            channel_id = self.goodbye_configs[guild_id]["channel_id"]
            channel = member.guild.get_channel(channel_id)
            if channel:
                try:
                    await channel.send(goodbye_message.format(member=member.mention, server=member.guild.name))
                    self.logger.info(f"Sent goodbye message for {member.name} in guild {member.guild.name} to channel {channel.name}.")
                except discord.Forbidden:
                    self.logger.error(f"Bot lacks permissions to send messages in goodbye channel {channel.name} in guild {member.guild.name}.")
                except Exception as e:
                    self.logger.error(f"Error sending goodbye message for {member.name} in guild {member.guild.name}: {e}")
            else:
                self.logger.warning(f"Goodbye channel with ID {channel_id} not found in guild {member.guild.name}. It might have been deleted.")

async def setup(bot):
    await bot.add_cog(Goodbye(bot))