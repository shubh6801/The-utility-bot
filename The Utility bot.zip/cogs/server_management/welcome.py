import discord
from discord.ext import commands
from discord import app_commands
import logging
import json
import os

logger = logging.getLogger(__name__)

class Welcome(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.welcome_configs_file = "config/welcome_messages.json"
        self.welcome_configs = {}
        self._load_welcome_configs()

    def _load_welcome_configs(self):
        if os.path.exists(self.welcome_configs_file):
            with open(self.welcome_configs_file, 'r') as f:
                self.welcome_configs = json.load(f)
        logger.info("Welcome configurations loaded successfully.")

    def _save_welcome_configs(self):
        with open(self.welcome_configs_file, 'w') as f:
            json.dump(self.welcome_configs, f, indent=4)
        logger.info("Welcome configurations saved successfully.")

    server = app_commands.Group(name="server", description="Server management commands")

    @server.command(name="set_welcome_channel", description="Sets the channel for welcome messages.")
    @app_commands.checks.has_permissions(manage_guild=True)
    async def set_welcome_channel(self, interaction: discord.Interaction, channel: discord.TextChannel):
        await interaction.response.defer(ephemeral=True)
        guild_id = str(interaction.guild_id)
        if guild_id not in self.welcome_configs:
            self.welcome_configs[guild_id] = {"message": None, "channel_id": None}
        self.welcome_configs[guild_id]["channel_id"] = channel.id
        self._save_welcome_configs()
        logger.info(f"Welcome channel set to {channel.name} by {interaction.user.name} in {interaction.guild.name}")
        await interaction.followup.send(f"Welcome messages will now be sent to {channel.mention}.", ephemeral=True)

    @app_commands.command(name="welcome", description="Sets up the welcome message for new members.")
    @app_commands.describe(message="The welcome message to set. Use {member} for mention, {server} for server name.")
    @app_commands.checks.has_permissions(manage_guild=True)
    async def welcome(self, interaction: discord.Interaction, message: str):
        await interaction.response.defer(ephemeral=True)
        try:
            guild_id = str(interaction.guild_id)
            if guild_id not in self.welcome_configs:
                self.welcome_configs[guild_id] = {"message": None, "channel_id": None}
            self.welcome_configs[guild_id]["message"] = message
            self._save_welcome_configs()
            logger.info(f"Welcome message set by {interaction.user.name} in {interaction.guild.name}: {message}")
            await interaction.followup.send(f"Welcome message has been set to: ```{message}```", ephemeral=True)
        except Exception as e:
            logger.error(f"Error setting welcome message: {e}", exc_info=True)
            await interaction.followup.send("An error occurred while setting the welcome message.", ephemeral=True)

    @commands.Cog.listener()
    async def on_member_join(self, member: discord.Member):
        guild_id = str(member.guild.id)
        if guild_id in self.welcome_configs and self.welcome_configs[guild_id]["message"] and self.welcome_configs[guild_id]["channel_id"]:
            welcome_message = self.welcome_configs[guild_id]["message"]
            welcome_channel_id = self.welcome_configs[guild_id]["channel_id"]

            # Replace placeholders
            welcome_message = welcome_message.replace("{member}", member.mention)
            welcome_message = welcome_message.replace("{server}", member.guild.name)

            channel = self.bot.get_channel(welcome_channel_id)
            if channel:
                try:
                    await channel.send(welcome_message)
                    logger.info(f"Sending welcome message to {member.display_name} in {member.guild.name} channel {channel.name}.")
                except discord.Forbidden:
                    logger.warning(f"Bot lacks permissions to send welcome message to channel {channel.name} in guild {member.guild.name}.")
            else:
                logger.warning(f"Welcome channel with ID {welcome_channel_id} not found for guild {member.guild.name}.")

    @welcome.error
    async def welcome_error(self, interaction: discord.Interaction, error):
        if isinstance(error, app_commands.MissingPermissions):
            logger.warning(f"User {interaction.user.id} attempted to use welcome command without permissions.")
            await interaction.response.send_message("You don't have permission to use this command.", ephemeral=True)
        else:
            logger.error(f"An unexpected error occurred in welcome_error handler for user {interaction.user.id}: {error}", exc_info=True)
            await interaction.response.send_message(f"An unexpected error occurred: {error}", ephemeral=True)

async def setup(bot):
    await bot.add_cog(Welcome(bot))