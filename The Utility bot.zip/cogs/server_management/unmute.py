import discord
from discord import app_commands
from discord.ext import commands
import datetime
import logging

logger = logging.getLogger(__name__)

class Unmute(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="unmute", description="Unmutes a user in the server.")
    @app_commands.checks.has_permissions(moderate_members=True)
    @app_commands.guild_only()
    async def unmute(self, interaction: discord.Interaction, user: discord.Member, reason: str = "No reason provided."):
        try:
            if not interaction.guild:
                await interaction.response.send_message("This command can only be used in a server.", ephemeral=True)
                logger.warning(f"Unmute command used outside guild by {interaction.user.name}")
                return

            if user.is_timed_out():
                await user.timeout(None, reason=reason)
                embed = discord.Embed(
                    title="User Unmuted",
                    description=f"{user.mention} has been unmuted.",
                    color=discord.Color.green(),
                    timestamp=datetime.datetime.now()
                )
                embed.add_field(name="Moderator", value=interaction.user.mention, inline=True)
                embed.add_field(name="User", value=user.mention, inline=True)
                embed.add_field(name="Reason", value=reason, inline=False)
                await interaction.response.send_message(embed=embed)
                logger.info(f"User {user.name} ({user.id}) unmuted by {interaction.user.name} ({interaction.user.id}) for reason: {reason}")
            else:
                await interaction.response.send_message(f"{user.mention} is not currently muted.", ephemeral=True)
                logger.warning(f"Attempted to unmute {user.name} ({user.id}) who is not muted by {interaction.user.name} ({interaction.user.id}).")

        except discord.Forbidden:
            await interaction.response.send_message("I do not have permission to unmute this user. Please check my role permissions.", ephemeral=True)
            logger.error(f"Bot lacks permissions to unmute {user.name} ({user.id}) in guild {interaction.guild.name} ({interaction.guild.id}).")
        except Exception as e:
            await interaction.response.send_message(f"An unexpected error occurred: {e}", ephemeral=True)
            logger.error(f"An unexpected error occurred during unmute command for user {user.name} ({user.id}) by {interaction.user.name} ({interaction.user.id}): {e}", exc_info=True)

async def setup(bot):
    await bot.add_cog(Unmute(bot))