import discord
from discord import app_commands
from discord.ext import commands
import logging
import json

logger = logging.getLogger(__name__)

CONFIG_PATH = "config/autoroles.json"

class Autorole(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.logger = logging.getLogger(__name__)
        self.autoroles = self._load_autoroles()

    def _load_autoroles(self):
        try:
            with open(CONFIG_PATH, 'r') as f:
                return {int(k): v for k, v in json.load(f).items()}
        except FileNotFoundError:
            return {}
        except json.JSONDecodeError:
            self.logger.error(f"Error decoding JSON from {CONFIG_PATH}. Returning empty autoroles.")
            return {}

    def _save_autoroles(self):
        with open(CONFIG_PATH, 'w') as f:
            json.dump(self.autoroles, f, indent=4)

    server = app_commands.Group(name="server", description="Server management commands")

    @server.command(name="autorole", description="Sets a role to be automatically assigned to new members.")
    @app_commands.checks.has_permissions(manage_roles=True)
    async def autorole(self, interaction: discord.Interaction, role: discord.Role):
        try:
            self.autoroles[interaction.guild.id] = role.id
            self._save_autoroles()
            await interaction.response.send_message(f"Autorole set to {role.mention}. New members will now receive this role.", ephemeral=True)
            self.logger.info(f"Autorole set to {role.name} ({role.id}) by {interaction.user.name} in guild {interaction.guild.name} ({interaction.guild.id})")
        except discord.Forbidden:
            self.logger.error(f"Bot lacks permissions to manage roles in guild {interaction.guild.name}.")
            await interaction.response.send_message("I do not have permission to manage roles.", ephemeral=True)
        except Exception as e:
            self.logger.error(f"Error setting autorole in guild {interaction.guild.name}: {e}")
            await interaction.response.send_message("An error occurred while trying to set the autorole.", ephemeral=True)

    @commands.Cog.listener()
    async def on_member_join(self, member):
        if member.guild.id in self.autoroles:
            role_id = self.autoroles[member.guild.id]
            role = member.guild.get_role(role_id)
            if role:
                try:
                    await member.add_roles(role)
                    self.logger.info(f"Assigned autorole {role.name} to new member {member.name} in guild {member.guild.name}.")
                except discord.Forbidden:
                    self.logger.error(f"Bot lacks permissions to assign role {role.name} to {member.name} in guild {member.guild.name}.")
                except Exception as e:
                    self.logger.error(f"Error assigning autorole {role.name} to {member.name} in guild {member.guild.name}: {e}")
            else:
                self.logger.warning(f"Autorole with ID {role_id} not found in guild {member.guild.name}. It might have been deleted.")

async def setup(bot):
    await bot.add_cog(Autorole(bot))