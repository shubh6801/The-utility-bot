import discord
from discord.ext import commands
from discord import app_commands
import logging

logger = logging.getLogger(__name__)

class Kick(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="kick", description="Kicks a user from the server.")
    @app_commands.describe(member="The member to kick.", reason="The reason for the kick.")
    @commands.has_permissions(kick_members=True)
    async def kick(self, interaction: discord.Interaction, member: discord.Member, reason: str = "No reason provided."):
        await interaction.response.defer(ephemeral=True)

        try:
            if member == interaction.user:
                await interaction.followup.send("You cannot kick yourself.")
                logger.warning(f"Self-kick attempt by {interaction.user.name} ({interaction.user.id}).")
                return

            if member.top_role >= interaction.user.top_role and interaction.user.id != interaction.guild.owner_id:
                await interaction.followup.send("You cannot kick someone with an equal or higher role than yourself.")
                logger.warning(f"Kick attempt on higher/equal role member {member.name} ({member.id}) by {interaction.user.name} ({interaction.user.id}).")
                return

            if not member.kickable:
                await interaction.followup.send("I cannot kick this member. They might have a higher role or I might not have the necessary permissions.")
                logger.warning(f"Bot cannot kick member {member.name} ({member.id}) due to permissions or role hierarchy.")
                return

            await member.kick(reason=reason)
            embed = discord.Embed(
                title="User Kicked",
                description=f"Successfully kicked {member.mention} (ID: `{member.id}`).",
                color=discord.Color.orange()
            )
            embed.add_field(name="Reason", value=reason, inline=False)
            embed.set_footer(text=f"Kicked by {interaction.user.display_name}")
            await interaction.followup.send(embed=embed)
            logger.info(f"Member {member.name} ({member.id}) kicked by {interaction.user.name} ({interaction.user.id}) for reason: {reason}.")
        except discord.Forbidden:
            await interaction.followup.send("I do not have permission to kick members.")
            logger.error(f"Bot lacked permissions to kick member {member.name} ({member.id}).")
        except Exception as e:
            await interaction.followup.send(f"An error occurred while trying to kick the user: {e}")
            logger.error(f"Error in kick command for member {member.name} ({member.id}): {e}")

async def setup(bot):
    await bot.add_cog(Kick(bot))