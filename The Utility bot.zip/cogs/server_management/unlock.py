import discord
from discord import app_commands
from discord.ext import commands
import logging

logger = logging.getLogger(__name__)

class Unlock(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    server = app_commands.Group(name="server", description="Server management commands")

    @server.command(name="unlock", description="Unlocks the current channel or a specified channel.")
    @app_commands.checks.has_permissions(manage_channels=True)
    async def unlock(self, interaction: discord.Interaction, channel: discord.TextChannel = None):
        await interaction.response.defer(ephemeral=True)
        if not channel:
            channel = interaction.channel

        try:
            await channel.set_permissions(interaction.guild.default_role, send_messages=True)
            await interaction.followup.send(f"🔓 {channel.mention} has been unlocked.", ephemeral=True)
            logger.info(f"Channel {channel.name} unlocked by {interaction.user.name}")
        except discord.Forbidden:
            logger.error(f"Bot lacks permissions to unlock channel {channel.name}.")
            await interaction.followup.send("I do not have permission to manage channels.", ephemeral=True)
        except Exception as e:
            logger.error(f"Error unlocking channel {channel.name}: {e}")
            await interaction.followup.send("An error occurred while trying to unlock the channel.", ephemeral=True)

    @unlock.error
    async def unlock_error(self, interaction: discord.Interaction, error):
        if isinstance(error, app_commands.MissingPermissions):
            logger.warning(f"User {interaction.user.id} attempted to use unlock command without permissions.")
            await interaction.response.send_message("You don't have permission to use this command.", ephemeral=True)
        else:
            logger.error(f"An unexpected error occurred in unlock_error handler for user {interaction.user.id}: {error}", exc_info=True)
            await interaction.response.send_message(f"An unexpected error occurred: {error}", ephemeral=True)

async def setup(bot):
    await bot.add_cog(Unlock(bot))