import os
import logging

import discord
from discord import app_commands
from discord.ext import commands
from lyricsgenius import Genius

logger = logging.getLogger(__name__)


class Lyrics(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.genius_token = os.getenv("GENIUS_ACCESS_TOKEN")
        if not self.genius_token:
            logger.error("GENIUS_ACCESS_TOKEN not found in config. Lyrics command will not work.")
            self.genius = None
        else:
            self.genius = Genius(self.genius_token)
            self.genius.remove_section_headers = True  # Remove [Chorus], [Verse], etc.
            self.genius.skip_lines = True  # Skip blank lines

    music = app_commands.Group(name="music", description="Music playback commands")

    @music.command(name="lyrics", description="Searches for lyrics of a song.")
    async def lyrics(self, interaction: discord.Interaction, song_title: str, artist_name: str = None):
        await interaction.response.defer()

        if not self.genius:
            await interaction.followup.send("Lyrics command is not configured. Please provide a Genius Access Token.")
            return

        try:
            if artist_name:
                song = self.genius.search_song(song_title, artist_name)
            else:
                song = self.genius.search_song(song_title)

            if song:
                embed = discord.Embed(
                    title=f"{song.title} by {song.artist}",
                    description=song.lyrics,
                    color=discord.Color.blue()
                )
                embed.set_thumbnail(url=song.song_art_image_url)
                await interaction.followup.send(embed=embed)
                logger.info(f"Lyrics found for {song.title} by {song.artist} in guild: {interaction.guild.id}")
            else:
                await interaction.followup.send(f"Could not find lyrics for '{song_title}' by '{artist_name or 'any artist'}'.")
                logger.info(f"No lyrics found for {song_title} by {artist_name or 'any artist'} in guild: {interaction.guild.id}")
        except Exception as e:
            logger.error(f"Error fetching lyrics for {song_title}: {e}")
            await interaction.followup.send("An error occurred while trying to fetch lyrics.")


def setup(bot):
    bot.add_cog(Lyrics(bot))