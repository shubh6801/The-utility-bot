import discord
from discord import app_commands
from discord.ext import commands
import asyncpraw
import os
import logging
import random

logger = logging.getLogger(__name__)

class Meme(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.reddit = asyncpraw.Reddit(
            client_id=os.getenv("REDDIT_CLIENT_ID"),
            client_secret=os.getenv("REDDIT_CLIENT_SECRET"),
            user_agent=os.getenv("REDDIT_USER_AGENT"),
        )

    meme_commands = app_commands.Group(name="meme", description="Commands for generating memes.")

    @meme_commands.command(name="random", description="Displays a random meme from a specified or default subreddit.")
    async def random_meme(self, interaction: discord.Interaction, subreddit_name: str = "memes"):
        """
        Displays a random meme from a specified or default subreddit.
        """
        await interaction.response.defer()
        try:
            subreddit = await self.reddit.subreddit(subreddit_name)
            posts = []
            async for post in subreddit.hot(limit=100):
                if not post.stickied and not post.over_18 and (post.url.endswith((".jpg", ".png", ".gif", ".jpeg")) or "i.redd.it" in post.url):
                    posts.append(post)
            
            if not posts:
                await interaction.followup.send(f"Could not find any suitable memes in r/{subreddit_name}. It might be private, quarantined, or empty, or contain no image posts.", ephemeral=True)
                return

            post = random.choice(posts)

            embed = discord.Embed(
                title=post.title,
                url=f"https://reddit.com{post.permalink}",
                color=discord.Color.blue()
            )
            embed.set_image(url=post.url)
            embed.set_footer(text=f"r/{subreddit_name} | Posted by u/{post.author.name} | ⬆️ {post.score}")
            
            await interaction.followup.send(embed=embed)
            logger.info(f"Successfully displayed random meme from r/{subreddit_name} for {interaction.user.name}")

        except Exception as e:
            logger.error(f"Error fetching random meme for r/{subreddit_name}: {e}")
            await interaction.followup.send(f"An error occurred while trying to fetch a meme from r/{subreddit_name}. Please check the subreddit name and try again.", ephemeral=True)

def setup(bot):
    bot.add_cog(Meme(bot))