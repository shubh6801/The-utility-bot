import logging

import discord
from discord import app_commands
from discord.ext import commands

logger = logging.getLogger(__name__)


class Volume(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    music = app_commands.Group(name="music", description="Music playback commands")

    @music.command(name="volume", description="Sets the playback volume.")
    async def volume(self, interaction: discord.Interaction, level: int):
        await interaction.response.defer()
        player = self.bot.get_cog('Play').get_player(interaction.guild.id)

        if not player or not player.voice_client or not player.voice_client.is_playing():
            await interaction.followup.send("No music is currently playing.")
            return

        if not 0 <= level <= 100:
            await interaction.followup.send("Volume level must be between 0 and 100.")
            return

        player.set_volume(level)
        await interaction.followup.send(f"Volume set to {level}%.")
        logger.info(f"Volume set to {level}% in guild: {interaction.guild.id}")


def setup(bot):
    bot.add_cog(Volume(bot))