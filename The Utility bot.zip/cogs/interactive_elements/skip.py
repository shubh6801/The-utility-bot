import logging

import discord
from discord import app_commands
from discord.ext import commands

logger = logging.getLogger(__name__)


class Skip(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    music = app_commands.Group(name="music", description="Music playback commands")

    @music.command(name="skip", description="Skips the current song.")
    async def skip(self, interaction: discord.Interaction):
        await interaction.response.defer()
        player = self.bot.get_cog('Play').get_player(interaction.guild.id)

        if not player or not player.voice_client or not player.voice_client.is_playing():
            await interaction.followup.send("No music is currently playing.")
            return

        player.voice_client.stop()
        logger.info(f"Skipped song in guild: {interaction.guild.id}")
        await interaction.followup.send("Skipped the current song.")


def setup(bot):
    bot.add_cog(Skip(bot))