import asyncio
import logging
import re

import discord
import youtube_dl
from discord import app_commands
from discord.ext import commands

logger = logging.getLogger(__name__)


class MusicPlayer:
    def __init__(self, bot):
        self.bot = bot
        self.queue = asyncio.Queue()
        self.current_song = None
        self.voice_client = None
        self.player_task = None
        self.loop_mode = "none"  # "none", "song", "queue"
        self.volume = 1.0  # Default volume

    def set_volume(self, level):
        self.volume = level / 100.0
        if self.voice_client and self.voice_client.is_playing():
            self.voice_client.source.volume = self.volume

    async def play_next_song(self, interaction: discord.Interaction):
        if self.voice_client is None or not self.voice_client.is_connected():
            logger.warning("Voice client not connected, stopping player task.")
            self.player_task = None
            return

        # Handle song looping
        if self.loop_mode == "song" and self.current_song:
            song_to_play = self.current_song
            logger.info(f"Looping current song: {song_to_play['title']}")
        elif not self.queue.empty():
            song_to_play = await self.queue.get()
            self.current_song = song_to_play
            logger.info(f"Playing next song: {song_to_play['title']}")
        elif self.loop_mode == "queue" and self.current_song:
            # If queue is empty but queue loop is on, re-add current song and then play from queue
            await self.queue.put(self.current_song)
            song_to_play = await self.queue.get()
            self.current_song = song_to_play
            logger.info(f"Looping queue, playing: {song_to_play['title']}")
        else:
            self.current_song = None
            await interaction.followup.send("Queue finished. Disconnecting from voice channel in 5 minutes if idle.")
            await asyncio.sleep(300)  # Wait 5 minutes
            if self.voice_client and not self.voice_client.is_playing() and self.queue.empty():
                await self.voice_client.disconnect()
                self.voice_client = None
                logger.info("Disconnected from voice channel due to inactivity.")
            return

        try:
            # Ensure the file exists before playing
            if not song_to_play.get('url'):
                logger.error(f"No URL found for song: {song_to_play['title']}")
                await interaction.followup.send(f"Error: Could not play {song_to_play['title']}. No direct URL found.")
                self.bot.loop.call_later(1, lambda: self.bot.loop.create_task(self.play_next_song(interaction)))
                return

            audio_source = discord.FFmpegPCMAudio(song_to_play['url'], **YDL_OPTIONS)
            audio_source = discord.PCMVolumeTransformer(audio_source, volume=self.volume)
            self.voice_client.play(audio_source,
                                   after=lambda e: self.bot.loop.call_later(1,
                                                                           lambda:
                                                                               self.bot.loop.create_task(
                                                                                   self.play_next_song(interaction))))
            await interaction.followup.send(f"Now playing: `{song_to_play['title']}`")
        except Exception as e:
            logger.error(f"Error playing song {song_to_play['title']}: {e}")
            await interaction.followup.send(f"Error playing song: {song_to_play['title']}. Skipping...")
            self.bot.loop.call_later(1, lambda: self.bot.loop.create_task(self.play_next_song(interaction)))


YDL_OPTIONS = {
    'format': 'bestaudio/best',
    'noplaylist': True,
    'default_search': 'auto',
    'quiet': True,
    'extractaudio': True,
    'audioformat': 'mp3',
    'outtmpl': './temp_audio/%(extractor)s-%(id)s-%(title)s.%(ext)s',
    'restrictfilenames': True,
    'nocheckcertificate': True,
    'ignoreerrors': False,
    'logtostderr': False,
    'no_warnings': True,
    'cachedir': False,
    'source_address': '0.0.0.0'  # bind to ipv4 since ipv6 addresses cause issues sometimes
}

FFMPEG_OPTIONS = {
    'before_options': '-reconnect 1 -reconnect_streamed 1 -reconnect_delay_max 5',
    'options': '-vn'
}


class Play(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.players = {}

    def get_player(self, guild_id):
        if guild_id not in self.players:
            self.players[guild_id] = MusicPlayer(self.bot)
        return self.players[guild_id]

    music = app_commands.Group(name="music", description="Music playback commands")

    @music.command(name="play", description="Plays a song from YouTube or a URL.")
    async def play(self, interaction: discord.Interaction, query: str):
        await interaction.response.defer()
        player = self.get_player(interaction.guild.id)

        if not interaction.user.voice:
            await interaction.followup.send("You need to be in a voice channel to play music!")
            return

        if player.voice_client is None:
            player.voice_client = await interaction.user.voice.channel.connect()
            logger.info(f"Bot connected to voice channel: {interaction.user.voice.channel.name}")

        if not player.voice_client.is_connected():
            player.voice_client = await interaction.user.voice.channel.connect()
            logger.info(f"Bot reconnected to voice channel: {interaction.user.voice.channel.name}")

        try:
            with youtube_dl.YoutubeDL(YDL_OPTIONS) as ydl:
                info = ydl.extract_info(query, download=False)
                if 'entries' in info:
                    info = info['entries'][0]  # Take the first result if it's a playlist/search result

                song = {
                    'id': info['id'],
                    'title': info['title'],
                    'url': info['url'],
                    'webpage_url': info['webpage_url'],
                    'thumbnail': info['thumbnail']
                }
                await player.queue.put(song)
                await interaction.followup.send(f"Added to queue: `{song['title']}`")

                if not player.player_task or player.player_task.done():
                    player.player_task = self.bot.loop.create_task(player.play_next_song(interaction))

        except youtube_dl.DownloadError as e:
            logger.error(f"YouTube-DL error: {e}")
            await interaction.followup.send(
                "Could not find or download the requested song. Please check the URL or search query.")
        except Exception as e:
            logger.error(f"Error in play command: {e}")
            await interaction.followup.send("An unexpected error occurred while trying to play the song.")


def setup(bot):
    bot.add_cog(Play(bot))