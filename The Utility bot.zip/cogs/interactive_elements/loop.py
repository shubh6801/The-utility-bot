import logging

from discord import app_commands
from discord.ext import commands
import discord

logger = logging.getLogger(__name__)


class Loop(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    music = app_commands.Group(name="music", description="Music playback commands")

    @music.command(name="loop", description="Sets the loop mode for the current song or queue.")
    async def loop(self, interaction: discord.Interaction, mode: str):
        await interaction.response.defer()
        player = self.bot.get_cog('Play').get_player(interaction.guild.id)

        if not player:
            await interaction.followup.send("No music player found for this guild.")
            return

        if mode.lower() == "none":
            player.loop_mode = "none"
            await interaction.followup.send("Loop mode set to: None.")
            logger.info(f"Loop mode set to None in guild: {interaction.guild.id}")
        elif mode.lower() == "song":
            player.loop_mode = "song"
            await interaction.followup.send("Loop mode set to: Song.")
            logger.info(f"Loop mode set to Song in guild: {interaction.guild.id}")
        elif mode.lower() == "queue":
            player.loop_mode = "queue"
            await interaction.followup.send("Loop mode set to: Queue.")
            logger.info(f"Loop mode set to Queue in guild: {interaction.guild.id}")
        else:
            await interaction.followup.send("Invalid loop mode. Choose from 'none', 'song', 'queue'.")


def setup(bot):
    bot.add_cog(Loop(bot))