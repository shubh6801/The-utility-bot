import discord
from discord.ext import commands
from discord import app_commands
import logging

logger = logging.getLogger(__name__)

class Permissions(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    # Example of a command that requires a specific permission
    @app_commands.command(name="test_admin", description="Tests if the user has administrator permissions.")
    @app_commands.checks.has_permissions(administrator=True)
    async def test_admin(self, interaction: discord.Interaction):
        await interaction.response.send_message("You have administrator permissions!", ephemeral=True)
        logger.info(f"{interaction.user.name} successfully used test_admin command.")

    # Example of a command that requires a specific role (by name)
    @app_commands.command(name="test_role", description="Tests if the user has a specific role.")
    async def test_role(self, interaction: discord.Interaction, role_name: str):
        required_role = discord.utils.get(interaction.guild.roles, name=role_name)
        if not required_role:
            await interaction.response.send_message(f"Role '{role_name}' not found in this server.", ephemeral=True)
            logger.warning(f"Role '{role_name}' not found when {interaction.user.name} used test_role command.")
            return

        if required_role in interaction.user.roles:
            await interaction.response.send_message(f"You have the '{role_name}' role!", ephemeral=True)
            logger.info(f"{interaction.user.name} successfully used test_role command with role '{role_name}'.")
        else:
            await interaction.response.send_message(f"You do not have the '{role_name}' role.", ephemeral=True)
            logger.warning(f"{interaction.user.name} failed to use test_role command (missing role '{role_name}').")

    @test_admin.error
    async def test_admin_error(self, interaction: discord.Interaction, error):
        if isinstance(error, app_commands.MissingPermissions):
            await interaction.response.send_message("You don't have the necessary permissions to use this command (Administrator).", ephemeral=True)
            logger.warning(f"{interaction.user.name} tried to use test_admin command without permissions.")
        else:
            await interaction.response.send_message(f"An error occurred: {error}", ephemeral=True)
            logger.error(f"Unhandled error in test_admin command: {error}")

async def setup(bot):
    await bot.add_cog(Permissions(bot))