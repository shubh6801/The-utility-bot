import discord
import os
from discord.ext import commands
from dotenv import load_dotenv
import datetime
import logging

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger('discord_bot')

load_dotenv()

intents = discord.Intents.all()
intents.message_content = True

bot = commands.Bot(command_prefix="!", intents=intents)
bot.uptime = datetime.datetime.utcnow()

@bot.event
async def on_ready():
    logger.info(f'Logged in as {bot.user}')
    logger.info(f'Bot ID: {bot.user.id}')
    logger.info('------')

    for folder in os.listdir("cogs"):
        if os.path.isdir(os.path.join("cogs", folder)):
            for filename in os.listdir(os.path.join("cogs", folder)):
                if filename.endswith(".py"):
                    try:
                        await bot.load_extension(f"cogs.{folder}.{filename[:-3]}")
                        logger.info(f"Loaded cog: {filename}")
                    except Exception as e:
                        logger.error(f"Failed to load cog {filename}: {e}")

    try:
        synced = await bot.tree.sync()
        logger.info(f"Synced {len(synced)} command(s)")
    except Exception as e:
        logger.error(f"Failed to sync commands: {e}")


DISCORD_BOT_TOKEN = os.getenv("DISCORD_BOT_TOKEN")

if DISCORD_BOT_TOKEN:
    bot.run(DISCORD_BOT_TOKEN)
else:
    logger.error("Error: DISCORD_BOT_TOKEN not found in environment variables.")